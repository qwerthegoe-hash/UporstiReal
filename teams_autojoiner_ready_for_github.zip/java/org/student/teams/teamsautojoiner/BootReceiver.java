package org.student.teams.teamsautojoiner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Запускает Python-сервис после перезагрузки телефона / обновления приложения. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                && !"android.intent.action.QUICKBOOT_POWERON".equals(a)) return;
        try {
            // Класс сервиса генерирует p4a: Service + Имя (первая буква заглавная, остальные строчные)
            ServiceTeamsservice.start(ctx, "boot");
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
