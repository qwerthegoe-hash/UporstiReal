package org.student.teams.teamsautojoiner;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/** Виджет: ближайший урок и состояние автоматизации. Данные пишет Python (widget.json). */
public class LessonWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        JSONObject d = read(ctx);
        String title = d.optString("title", "Откройте приложение");
        String when = d.optString("when", "");
        String status = d.optString("status", "");

        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        PendingIntent pi = launch == null ? null : PendingIntent.getActivity(
                ctx, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        for (int id : ids) {
            RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_lesson);
            v.setTextViewText(R.id.w_title, title);
            v.setTextViewText(R.id.w_when, when);
            v.setTextViewText(R.id.w_status, status);
            if (pi != null) v.setOnClickPendingIntent(R.id.w_root, pi);
            mgr.updateAppWidget(id, v);
        }
    }

    private static JSONObject read(Context ctx) {
        try (BufferedReader r = new BufferedReader(
                new FileReader(new File(ctx.getFilesDir(), "widget.json")))) {
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l);
            return new JSONObject(sb.toString());
        } catch (Exception e) {
            return new JSONObject();
        }
    }
}
