package org.student.teams.teamsautojoiner;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;

/** Кнопки уведомления: пишет action.json и будит Python-сервис. */
public class LessonActionReceiver extends BroadcastReceiver {

    static final String ACTION_JOIN = "org.student.teams.teamsautojoiner.ACTION_JOIN";
    static final String ACTION_SKIP = "org.student.teams.teamsautojoiner.ACTION_SKIP";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        String sid = intent.getStringExtra("sid");
        int nid = intent.getIntExtra("nid", 0);
        String act = ACTION_JOIN.equals(a) ? "join" : ACTION_SKIP.equals(a) ? "skip" : null;
        if (act == null || sid == null) return;
        try {
            JSONObject o = new JSONObject().put("action", act).put("id", sid)
                    .put("ts", System.currentTimeMillis());
            try (FileWriter w = new FileWriter(new File(ctx.getFilesDir(), "action.json"))) {
                w.write(o.toString());
            }
            ServiceTeamsservice.start(ctx, "action");
        } catch (Throwable t) {
            t.printStackTrace();
        }
        ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid);
    }
}
