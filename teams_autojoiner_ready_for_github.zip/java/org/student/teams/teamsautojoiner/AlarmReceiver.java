package org.student.teams.teamsautojoiner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Точный будильник (перед уроком / keep-alive): поднимает Python-сервис. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try { ServiceTeamsservice.start(ctx, "alarm"); } catch (Throwable t) { t.printStackTrace(); }
    }
}
