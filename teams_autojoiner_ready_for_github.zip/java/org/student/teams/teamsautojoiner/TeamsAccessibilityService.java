package org.student.teams.teamsautojoiner;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.io.*;
import java.util.*;

/**
 * Автомат состояний Teams (v1.2.0):
 *   searching → (not_started | lobby) → prejoin: выключить mic/cam → clicked → joined
 *   joined: постоянно следит, что mic/cam выключены → в конце урока leave → left
 * Блокировка: files/lock_request.json (пишет Python; Android 9+)
 * Вход:  files/join_armed.json   (пишет Python)
 * Выход: files/a11y_status.json  (stage, mic, cam; читает Python)
 *        files/a11y_dump.txt     (дерево экрана Teams — для отладки подписей кнопок)
 */
public class TeamsAccessibilityService extends AccessibilityService {

    private static final String TEAMS = "com.microsoft.teams";

    private static final Set<String> JOIN = set("join", "join now", "join meeting",
            "присоединиться", "присоединиться сейчас", "подключиться", "приєднатися", "приєднатися зараз");
    private static final Set<String> LEAVE = set("leave", "hang up", "end call", "leave meeting",
            "выйти", "завершить", "завершить вызов", "покинуть", "покинуть собрание", "вийти", "завершити");
    private static final Set<String> CONFIRM = set("leave", "выйти", "покинуть", "вийти", "ok", "ок");

    private static final String[] LOBBY = {"lobby", "let you in", "зал ожидания", "впустит", "впустят",
            "очікування", "впустить"};
    private static final String[] NOT_STARTED = {"not started", "hasn't started", "has not started",
            "waiting for the organizer", "ещё не началась", "еще не началась", "не началось", "не розпочалась"};

    private static final String[] MIC = {"microphone", "mic", "микрофон", "мікрофон", "mute"};
    private static final String[] CAM = {"camera", "video", "камер", "відео", "видео"};
    private static final String[] MIC_EXCL = {"speaker", "audio", "динамик", "звук", "reaction"};
    private static final String[] CAM_EXCL = {"flip", "switch", "background", "effect", "фон", "эффект",
            "переключ", "повернуть", "перевернуть"};

    private final Handler h = new Handler(Looper.getMainLooper());

    // состояние сессии
    private String sid = "";
    private boolean clicked, joined;
    private long joinedAt, lastJoinClick, lastMuteClick, lastTap, lastLeaveTry, leaveFirst, lastDump, lastStatus;
    private int micClicks, camClicks;
    private String leftFor = "", lastStage = "";
    private int lastMic = -1, lastCam = -1;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            boolean active = false;
            try { active = step(); } catch (Throwable t) { t.printStackTrace(); }
            h.postDelayed(this, active ? 700 : 3000);   // быстро, пока идёт урок
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        h.removeCallbacks(tick); h.post(tick);
        // запасной автозапуск Python-сервиса после перезагрузки
        try { ServiceTeamsservice.start(this, "a11y"); } catch (Throwable ignored) {}
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }

    // ── Главный шаг ─────────────────────────────────────────────────────────

    private boolean step() {
        checkLock();
        JSONObject a = armed();
        if (a == null) return false;
        long now = System.currentTimeMillis();
        String id = a.optString("id");
        if (!id.equals(sid)) {                       // новая сессия — сброс
            sid = id; clicked = joined = false; micClicks = camClicks = 0; leaveFirst = 0;
            lastStage = ""; lastMic = lastCam = -1;
        }
        long joinFrom = a.optLong("join_from"), joinUntil = a.optLong("join_until"), leaveAt = a.optLong("leave_at");
        boolean wantMic = a.optBoolean("mute_mic", true), wantCam = a.optBoolean("mute_cam", true);
        if (now < joinFrom) return false;
        if (leftFor.equals(id)) { status("left", now); return false; }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !TEAMS.contentEquals(root.getPackageName())) {
            status("teams_not_foreground", now);
            return true;
        }
        dump(root, now);

        if (leaveAt > 0 && now >= leaveAt) { tryLeave(root, id, now); return true; }

        boolean hasJoin  = find(root, JOIN) != null;
        boolean hasLeave = find(root, LEAVE) != null;

        if (joined) {                                // в звонке: следим за mic/cam
            guardMute(root, now, wantMic, wantCam, true);
            status("joined", now);
        } else if (hasContains(root, LOBBY)) {
            status("lobby", now);
        } else if (hasJoin && now <= joinUntil) {
            if (guardMute(root, now, wantMic, wantCam, false)) return true;   // сначала выключить mic/cam
            if (now - lastJoinClick > 3000) {
                AccessibilityNodeInfo j = find(root, JOIN);
                if (j != null && click(j)) { lastJoinClick = now; clicked = true; }
            }
            status(clicked ? "clicked" : "prejoin", now);
        } else if (hasLeave || (clicked && !hasJoin)) {
            joined = true; joinedAt = now;
            status("joined", now);
        } else if (hasContains(root, NOT_STARTED)) {
            status("not_started", now);
        } else {
            status("searching", now);
        }
        return true;
    }

    // ── Микрофон / камера ───────────────────────────────────────────────────

    /** true — если сделан клик (подождать следующего тика для проверки результата). */
    private boolean guardMute(AccessibilityNodeInfo root, long now, boolean wantMic, boolean wantCam, boolean inCall) {
        AccessibilityNodeInfo mic = findControl(root, MIC, MIC_EXCL, true);
        AccessibilityNodeInfo cam = findControl(root, CAM, CAM_EXCL, false);
        lastMic = mic == null ? -1 : state(mic, true);
        lastCam = cam == null ? -1 : state(cam, false);

        if (inCall && mic == null && cam == null && now - lastTap > 5000 && now - joinedAt < 180000) {
            lastTap = now; tapCenter();              // панель скрыта — показать
            return false;
        }
        if (now - lastMuteClick < 800) return false;
        // клик только если ТОЧНО определили «включено» (1); неизвестное (-1) не трогаем
        if (wantMic && lastMic == 1 && micClicks < 8 && click(mic)) { micClicks++; lastMuteClick = now; return true; }
        if (wantCam && lastCam == 1 && camClicks < 8 && click(cam)) { camClicks++; lastMuteClick = now; return true; }
        return false;
    }

    /** 1 — включено, 0 — выключено, -1 — не удалось определить. */
    private int state(AccessibilityNodeInfo n, boolean mic) {
        String s = ((n.getText() == null ? "" : n.getText()) + " "
                + (n.getContentDescription() == null ? "" : n.getContentDescription())).toLowerCase();
        if (mic) {
            if (s.contains("unmuted")) return 1;
            if (s.contains("unmute") || s.contains("muted")) return 0;
            if (s.contains("mute")) return 1;                         // «Mute» = действие → сейчас включён
        }
        if (s.contains("turn off") || s.contains("выключить") || s.contains("отключить") || s.contains("вимкнути")) return 1;
        if (s.contains("turn on") || s.contains("включить") || s.contains("увімкнути")) return 0;
        if (s.contains(" off") || s.contains("выключен") || s.contains("отключен") || s.contains("вимкнен")) return 0;
        if (s.contains(" on") || s.contains("включен") || s.contains("включён") || s.contains("увімкнен")) return 1;
        if (n.isCheckable()) return n.isChecked() ? 1 : 0;           // переключатель на экране входа
        return -1;
    }

    private AccessibilityNodeInfo findControl(AccessibilityNodeInfo n, String[] words, String[] excl, boolean mic) {
        if (n == null) return null;
        String s = ((n.getText() == null ? "" : n.getText()) + " "
                + (n.getContentDescription() == null ? "" : n.getContentDescription())).toLowerCase();
        if (n.isVisibleToUser() && !s.trim().isEmpty() && containsAny(s, words) && !containsAny(s, excl) && state(n, mic) != -1
                && (n.isClickable() || n.isCheckable() || (n.getParent() != null && n.getParent().isClickable()))) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findControl(n.getChild(i), words, excl, mic);
            if (r != null) return r;
        }
        return null;
    }

    // ── Выход ───────────────────────────────────────────────────────────────

    private void tryLeave(AccessibilityNodeInfo root, String id, long now) {
        status("leaving", now);
        if (leaveFirst == 0) leaveFirst = now;
        if (now - leaveFirst > 120000) { leftFor = id; return; }      // сдаёмся через 2 мин
        if (now - lastLeaveTry < 2500) return;
        lastLeaveTry = now;
        AccessibilityNodeInfo leave = find(root, LEAVE);
        if (leave != null && click(leave)) {
            h.postDelayed(() -> {
                AccessibilityNodeInfo r2 = getRootInActiveWindow();
                AccessibilityNodeInfo c = r2 == null ? null : find(r2, CONFIRM);
                if (c != null) click(c);
            }, 1000);
            leftFor = id;
        } else {
            tapCenter();
        }
    }

    // ── Блокировка экрана по запросу Python (после урока, Android 9+) ─────────

    private void checkLock() {
        File f = new File(getFilesDir(), "lock_request.json");
        if (!f.exists()) return;
        f.delete();
        if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }

    // ── Файлы ───────────────────────────────────────────────────────────────

    private JSONObject armed() {
        try {
            File f = new File(getFilesDir(), "join_armed.json");
            if (!f.exists()) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String l; while ((l = r.readLine()) != null) sb.append(l);
            }
            JSONObject o = new JSONObject(sb.toString());
            return o.has("id") ? o : null;
        } catch (Exception e) { return null; }
    }

    private void status(String stage, long now) {
        if (stage.equals(lastStage) && now - lastStatus < 5000) return;
        lastStage = stage; lastStatus = now;
        try {
            JSONObject o = new JSONObject();
            o.put("id", sid); o.put("stage", stage); o.put("mic", lastMic); o.put("cam", lastCam); o.put("ts", now);
            File f = new File(getFilesDir(), "a11y_status.json"), t = new File(getFilesDir(), "a11y_status.tmp");
            try (FileWriter w = new FileWriter(t)) { w.write(o.toString()); }
            t.renameTo(f);
        } catch (Exception ignored) {}
    }

    private void dump(AccessibilityNodeInfo root, long now) {
        if (now - lastDump < 5000) return;
        lastDump = now;
        StringBuilder sb = new StringBuilder("stage=" + lastStage + " mic=" + lastMic + " cam=" + lastCam + "\n");
        walk(root, 0, sb, new int[]{0});
        try (FileWriter w = new FileWriter(new File(getFilesDir(), "a11y_dump.txt"))) { w.write(sb.toString()); }
        catch (Exception ignored) {}
    }

    private void walk(AccessibilityNodeInfo n, int d, StringBuilder sb, int[] cnt) {
        if (n == null || cnt[0]++ > 250) return;
        CharSequence t = n.getText(), c = n.getContentDescription();
        if ((t != null && t.length() > 0) || (c != null && c.length() > 0) || n.isClickable() || n.isCheckable()) {
            for (int i = 0; i < d; i++) sb.append(' ');
            sb.append(n.getClassName()).append(" t=").append(t).append(" d=").append(c)
              .append(n.isClickable() ? " [click]" : "")
              .append(n.isCheckable() ? (n.isChecked() ? " [checked]" : " [unchecked]") : "").append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), d + 1, sb, cnt);
    }

    // ── Помощники ───────────────────────────────────────────────────────────

    private static Set<String> set(String... a) { return new HashSet<>(Arrays.asList(a)); }

    private static boolean containsAny(String s, String[] words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo n, Set<String> words) {
        if (n == null) return null;
        if (n.isVisibleToUser() && (eq(n.getText(), words) || eq(n.getContentDescription(), words))) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), words);
            if (r != null) return r;
        }
        return null;
    }

    private boolean eq(CharSequence s, Set<String> w) {
        return s != null && w.contains(s.toString().trim().toLowerCase());
    }

    private boolean hasContains(AccessibilityNodeInfo n, String[] phrases) {
        if (n == null) return false;
        CharSequence t = n.getText(), d = n.getContentDescription();
        String s = ((t == null ? "" : t) + " " + (d == null ? "" : d)).toLowerCase();
        if (containsAny(s, phrases)) return true;
        for (int i = 0; i < n.getChildCount(); i++) if (hasContains(n.getChild(i), phrases)) return true;
        return false;
    }

    private boolean click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n;
        while (x != null && !x.isClickable()) x = x.getParent();
        return x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private void tapCenter() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Path p = new Path();
        p.moveTo(dm.widthPixels / 2f, dm.heightPixels / 2f);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null);
    }
}
