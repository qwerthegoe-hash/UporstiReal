package org.student.teams.teamsautojoiner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/**
 * Уведомления уроков. Кнопки «Войти сейчас» и «Пропустить» шлют
 * LessonActionReceiver, который передаёт выбор Python-сервису.
 */
public class NotifyHelper {

    static final String CHANNEL = "lessons";

    public static void show(Context ctx, int nid, String title, String text,
                            String sid, boolean actions) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Уроки", NotificationManager.IMPORTANCE_HIGH));

        Notification.Builder b = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true);

        if (actions && sid != null && !sid.isEmpty()) {
            b.addAction(0, "Войти сейчас",
                    pending(ctx, LessonActionReceiver.ACTION_JOIN, sid, nid));
            b.addAction(0, "Пропустить",
                    pending(ctx, LessonActionReceiver.ACTION_SKIP, sid, nid));
        }
        nm.notify(nid, b.build());
    }

    private static PendingIntent pending(Context ctx, String action, String sid, int nid) {
        Intent i = new Intent(ctx, LessonActionReceiver.class)
                .setAction(action)
                .putExtra("sid", sid)
                .putExtra("nid", nid);
        int code = (action + sid).hashCode();
        return PendingIntent.getBroadcast(ctx, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
