"""
service/main.py — фоновый сервис Teams Auto-Joiner (v1.3.2)

Каждые 10 с:
  • обрабатывает кнопки уведомлений («Войти сейчас» / «Пропустить»);
  • за 5 минут до урока присылает уведомление с кнопками и предупреждением о сети;
  • подтягивает календарь, ставит будильники и входит на урок;
  • на время урока включает «Не беспокоить»; после — возвращает прежний режим и блокирует экран;
  • обновляет виджет на рабочем столе.
"""

import os
import sys
import time
import logging

_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _root not in sys.path:
    sys.path.insert(0, _root)

import core

log = logging.getLogger('tja')

PRE_NOTICE_SEC = 300      # уведомление за 5 минут до урока


def _launch(s: dict):
    from automation import TeamsAutomation
    auto = TeamsAutomation()
    auto.wake_and_unlock()
    auto.join_meeting(s['url'], mute_mic=s['mute_mic'], mute_cam=s['mute_cam'])


def _join(settings: dict, s: dict) -> bool:
    """Заходит на урок один раз. False, если вход уже был (или урок пропущен)."""
    state = core.load_state()
    if not core.mark_joined(state, s):
        return False
    log.info("вход: %s", s['name'])
    core.arm_accessibility(s, settings.get('leave_grace_seconds', 0))
    state['active'] = dict(s, launched_at=int(time.time() * 1000), retries=0)
    core.enter_quiet(settings, state)
    core.save_state(state)
    try:
        _launch(s)
    except Exception as e:
        log.error("ошибка запуска Teams: %s", e)
        core.notify(f"⏰ Урок: {s['name']}", "Войди вручную!")
    if not core.accessibility_enabled():
        core.notify("Teams Auto-Joiner",
                    "Включи службу «Специальные возможности», иначе кнопку "
                    "«Присоединиться» придётся нажимать вручную")
    return True


def _handle_action(settings: dict, data: dict):
    act = core.pop_action()
    if not act:
        return
    sid = act.get('id', '')
    state = core.load_state()
    found = [s for s in core.sessions_between(settings, data, state, -900, 900)
             if s['id'] == sid]
    if not found:
        core.notify("Teams Auto-Joiner", "Урок уже прошёл или больше не в расписании")
        return
    s = found[0]
    if act.get('action') == 'join':
        if not _join(settings, s):
            core.notify(f"ℹ️ {s['name']}", "Вход уже выполнен или урок пропущен")
    elif act.get('action') == 'skip':
        if core.already_handled(state, s):
            core.notify(f"ℹ️ {s['name']}", "Вход уже выполнен — пропуск не нужен")
        else:
            core.mark_joined(state, s)
            core.save_state(state)
            core.notify("⏭ Пропущено", s['name'])


def _pre_notify(settings: dict, data: dict):
    """За 5 минут до урока: уведомление с кнопками и предупреждением о сети."""
    state = core.load_state()
    now_ms = int(time.time() * 1000)
    notified = {k: v for k, v in state.get('notified', {}).items()
                if str(v).isdigit() and int(v) > now_ms - 172800000}
    changed = False
    for s in core.sessions_between(settings, data, state,
                                   core.buffer_seconds(settings), PRE_NOTICE_SEC):
        stamp = str(s['start_ms'])
        if notified.get(s['id']) == stamp or core.already_handled(state, s):
            continue
        notified[s['id']] = stamp
        changed = True
        mins = max(1, round((s['start_ms'] - now_ms) / 60000))
        text = f"Через {mins} мин. Войти автоматически или пропустить?"
        problem = core.net_problem(settings, core.network_status())
        if problem:
            text += f"\n⚠️ {problem} — подключись до урока"
        core.notify(f"📚 {s['name']}", text, s['id'], actions=True)
    if changed:
        state['notified'] = notified
        core.save_state(state)


def _check_and_trigger():
    data = core.load_lessons()
    settings = data.get('settings', {})
    if settings.get('automation_enabled', True):
        if settings.get('calendar_sync', True):
            core.sync_calendar()
        core.schedule_alarms(settings, data, core.load_state())
        _pre_notify(settings, data)
        for s in core.due_sessions(settings, data, core.load_state()):
            _join(settings, s)
    else:
        core.disarm_accessibility()
    core.push_widget(core.build_widget_state(settings, data, core.load_state()))


def _supervise():
    """Следит за статусом Teams, повторяет вход, шлёт отчёты, в конце урока возвращает DND."""
    state = core.load_state()
    act = state.get('active')
    if not act:
        return
    now = int(time.time() * 1000)
    st = core.read_status()
    stage = st.get('stage') if st.get('id') == act['id'] else 'none'
    settings = core.load_lessons().get('settings', {})

    if stage == 'left' or now > act['end_ms'] + 300000:
        state.pop('active', None)
        core.leave_quiet(settings, state)
        core.save_state(state)
        core.disarm_accessibility()
        if stage == 'left':
            core.notify(f"✅ {act['name']}", "Вышел из урока")
            if settings.get('lock_after_lesson', True):
                core.request_lock()
        return

    if stage in ('clicked', 'lobby', 'joined', 'leaving'):
        if stage == 'joined' and not act.get('reported'):
            act['reported'] = True
            core.notify(f"✅ {act['name']}: вошёл", core.describe_status(st))
            state['active'] = act
            core.save_state(state)
        return

    wait = 60000 if stage == 'not_started' else 75000
    if now - act['launched_at'] >= wait and now <= act['start_ms'] + 600000:
        if act['retries'] < 6:
            act['retries'] += 1
            act['launched_at'] = now
            state['active'] = act
            core.save_state(state)
            log.info("повтор #%d (этап: %s)", act['retries'], stage)
            try:
                _launch(act)
            except Exception as e:
                log.error("повтор не удался: %s", e)
        elif not act.get('failed'):
            act['failed'] = True
            state['active'] = act
            core.save_state(state)
            core.notify(f"⚠️ {act['name']}",
                        f"Не удалось войти (этап: {stage}). Войди вручную!")


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    log.info("Teams Auto-Joiner запущен")
    core.notify("Teams Auto-Joiner", "Мониторинг расписания активен")
    while True:
        try:
            data = core.load_lessons()
            settings = data.get('settings', {})
            _handle_action(settings, data)
            _check_and_trigger()
            _supervise()
        except Exception as e:
            log.exception("критическая ошибка цикла: %s", e)
        time.sleep(10)


if __name__ == '__main__':
    main()
