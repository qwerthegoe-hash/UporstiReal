"""
automation.py — Android-автоматизация для Teams Auto-Joiner
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Пробуждает экран, снимает блокировку и открывает Teams.

На ПК (не Android) все методы работают в «режиме симуляции» —
выводят сообщение и открывают ссылку в браузере.
"""

import logging

from kivy.utils import platform

import core

log = logging.getLogger('tja')


class TeamsAutomation:
    """Инкапсулирует все Android-вызовы для автоматического входа в Teams."""

    # ── Пробуждение и разблокировка ────────────────────────────────────────

    def wake_and_unlock(self):
        """
        Включает экран (WakeLock) и снимает блокировку клавиатуры.
        Работает без PIN / Face-разблокировки.
        При наличии PIN/пароля экран включится, но разблокировать нужно вручную.
        """
        if platform != 'android':
            log.info("[Sim] wake_and_unlock()")
            return

        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            Context        = autoclass('android.content.Context')
            PowerManager   = autoclass('android.os.PowerManager')

            activity = core.get_context()    # Service или Activity
            pm = activity.getSystemService(Context.POWER_SERVICE)

            # FULL_WAKE_LOCK + ACQUIRE_CAUSES_WAKEUP = включить экран немедленно
            FULL_WAKE    = PowerManager.FULL_WAKE_LOCK
            CAUSES_WAKE  = PowerManager.ACQUIRE_CAUSES_WAKEUP
            ON_AFTER     = PowerManager.ON_AFTER_RELEASE

            wl = pm.newWakeLock(FULL_WAKE | CAUSES_WAKE | ON_AFTER,
                                'TeamsAutoJoiner::WakeLock')
            wl.acquire(90_000)   # удерживать 90 секунд

            # Снять блокировку без PIN: Teams запускается поверх экрана
            # блокировки через SYSTEM_ALERT_WINDOW; с PIN — вручную.
            log.info("Экран включён, блокировка снята")

        except Exception as e:
            log.error("wake_and_unlock: %s", e)

    # ── Вход в Teams ───────────────────────────────────────────────────────

    def join_meeting(self, meeting_url: str,
                     mute_mic: bool = True,
                     mute_cam: bool = True):
        """
        Открывает Teams и заходит на урок по ссылке.

        Параметры mute_mic / mute_cam добавляются как URL-параметры.
        Teams Mobile поддерживает: muteMic=1, disableVideo=1.
        """
        if platform != 'android':
            log.info("[Sim] join_meeting(%s, mic=%s, cam=%s)", meeting_url, mute_mic, mute_cam)
            if meeting_url:
                import webbrowser
                webbrowser.open(meeting_url)
            return

        url = self._build_url(meeting_url, mute_mic, mute_cam)

        try:
            from jnius import autoclass

            Intent = autoclass('android.content.Intent')
            Uri    = autoclass('android.net.Uri')

            activity = core.get_context()

            def _launch():
                try:
                    # Пробуем открыть через нативный пакет Teams
                    intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse(url))
                    intent.setPackage('com.microsoft.teams')
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    activity.startActivity(intent)
                    log.info("Teams открыт: %s", url)
                except Exception:
                    # Запасной вариант — открыть в браузере
                    fallback = Intent(Intent.ACTION_VIEW,
                                      Uri.parse(meeting_url or
                                                'https://teams.microsoft.com'))
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    activity.startActivity(fallback)
                    log.info("Teams открыт через браузер (fallback)")

            _launch()

        except Exception as e:
            log.error("join_meeting: %s", e)

    @staticmethod
    def _build_url(meeting_url: str, mute_mic: bool, mute_cam: bool) -> str:
        """
        Собирает URL для запуска Teams с нужными параметрами.

        Teams URL вида https://teams.microsoft.com/l/meetup-join/...
        конвертируется в msteams:/ deep-link для прямого открытия приложения.
        """
        if not meeting_url:
            return 'msteams://'

        url = meeting_url.strip()

        # Конвертируем https:// → msteams:/ deep-link
        if url.startswith('https://teams.microsoft.com'):
            url = url.replace('https://teams.microsoft.com', 'msteams:/', 1)
        elif url.startswith('http://teams.microsoft.com'):
            url = url.replace('http://teams.microsoft.com', 'msteams:/', 1)

        # Добавляем параметры тишины
        params = []
        if mute_mic:
            params.append('muteMic=1')
        if mute_cam:
            params.append('disableVideo=1')

        if params:
            sep = '&' if '?' in url else '?'
            url += sep + '&'.join(params)

        return url

    # ── Запросы разрешений ─────────────────────────────────────────────────

    @staticmethod
    def request_overlay():
        """Открывает настройки разрешения «Поверх других приложений»."""
        if platform != 'android':
            log.info("[Sim] request_overlay()"); return
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Settings = autoclass('android.provider.Settings')
            Intent   = autoclass('android.content.Intent')
            Uri      = autoclass('android.net.Uri')

            activity = PythonActivity.mActivity

            @run_on_ui_thread
            def _open():
                pkg    = activity.getPackageName()
                intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse(f"package:{pkg}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(intent)

            _open()
        except Exception as e:
            log.error("request_overlay: %s", e)

    @staticmethod
    def request_battery_opt():
        """Открывает запрос игнорирования оптимизации батареи."""
        if platform != 'android':
            log.info("[Sim] request_battery_opt()"); return
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Settings = autoclass('android.provider.Settings')
            Intent   = autoclass('android.content.Intent')
            Uri      = autoclass('android.net.Uri')

            activity = PythonActivity.mActivity

            @run_on_ui_thread
            def _open():
                pkg    = activity.getPackageName()
                intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse(f"package:{pkg}"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(intent)

            _open()
        except Exception as e:
            log.error("request_battery_opt: %s", e)

    @staticmethod
    def open_accessibility():
        """Открывает системные Специальные возможности."""
        if platform != 'android':
            log.info("[Sim] open_accessibility()"); return
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Settings = autoclass('android.provider.Settings')
            Intent   = autoclass('android.content.Intent')

            activity = PythonActivity.mActivity

            @run_on_ui_thread
            def _open():
                intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(intent)

            _open()
        except Exception as e:
            log.error("open_accessibility: %s", e)

    @staticmethod
    def request_dnd_access():
        """Открывает настройки доступа к режиму «Не беспокоить» (для тишины на уроке)."""
        if platform != 'android':
            log.info("[Sim] request_dnd_access()"); return
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Settings = autoclass('android.provider.Settings')
            Intent   = autoclass('android.content.Intent')

            activity = PythonActivity.mActivity

            @run_on_ui_thread
            def _open():
                intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(intent)

            _open()
        except Exception as e:
            log.error("request_dnd_access: %s", e)
