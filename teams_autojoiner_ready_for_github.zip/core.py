"""
core.py — общая логика приложения и фонового сервиса (v1.3.2).
Без зависимостей от Kivy: импортируется и из service/main.py и из тестов.

Файлы в getFilesDir():
  lessons.json       — уроки и настройки (пишет приложение)
  state.json         — служебное: метки, события календаря, сохранённый DND (пишет сервис)
  join_armed.json    — «вооружение» для AccessibilityService (читает Java)
  a11y_status.json   — статус от AccessibilityService (пишет Java)
  action.json        — нажатие кнопки в уведомлении, с меткой времени (пишет Java)
  lock_request.json  — просьба заблокировать экран (пишет сервис, читает Java)
  widget.json        — данные виджета на рабочем столе (пишет сервис)
"""

import os
import re
import json
import time
import uuid
import zlib
import logging
from datetime import datetime, timedelta, date

log = logging.getLogger('tja')

TEAMS_URL_RE = re.compile(
    r'https://teams\.(?:microsoft|live)\.com/[^\s<>"\')\]]+', re.IGNORECASE)

DAYS_FULL = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье']

DAY_NAMES = {
    'пн': 0, 'понедельник': 0, 'mon': 0, 'monday': 0,
    'вт': 1, 'вторник': 1, 'tue': 1, 'tuesday': 1,
    'ср': 2, 'среда': 2, 'среду': 2, 'wed': 2, 'wednesday': 2,
    'чт': 3, 'четверг': 3, 'thu': 3, 'thursday': 3,
    'пт': 4, 'пятница': 4, 'пятницу': 4, 'fri': 4, 'friday': 4,
    'сб': 5, 'суббота': 5, 'субботу': 5, 'sat': 5, 'saturday': 5,
    'вс': 6, 'воскресенье': 6, 'sun': 6, 'sunday': 6,
}
WORD_RE = re.compile(r'[A-Za-zА-Яа-яЁё]+')
TIME_RANGE_RE = re.compile(r'(?<!\d)(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})(?!\d)')
TIME_RE = re.compile(r'(?<!\d)(\d{1,2})[:.](\d{2})(?!\d)')
HOLIDAY_RE = re.compile(r'каникул|праздник|holiday|vacation', re.IGNORECASE)

MIN_BUFFER_MIN = 1               # буфер до урока: не меньше минуты
MAX_BUFFER_MIN = 15
DUP_TOL_MS = 10 * 60000          # совпадение названия и времени в пределах 10 мин = дубль
ACTION_MAX_AGE_MS = 5 * 60000    # нажатие в уведомлении старше 5 мин игнорируется
STATUS_CANCELED = 2              # CalendarContract.Events.STATUS_CANCELED
ATTENDEE_DECLINED = 2            # CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED
INTERRUPTION_FILTER_ALL = 1      # NotificationManager.INTERRUPTION_FILTER_ALL
INTERRUPTION_FILTER_ALARMS = 4   # NotificationManager.INTERRUPTION_FILTER_ALARMS

NET_TEXT = {
    'no_internet': 'Нет интернета',
    'no_network': 'Нет Wi-Fi и мобильной сети',
    'cellular': 'Работает только мобильная сеть, не Wi-Fi',
}
_WIDGET_CLS = 'org.student.teams.teamsautojoiner.LessonWidgetProvider'
_NOTIFY_CLS = 'org.student.teams.teamsautojoiner.NotifyHelper'
_last_widget = None


# ── Пути и контекст ───────────────────────────────────────────────────────────

def get_context():
    """Context из сервиса (mService) или из приложения (mActivity). None на ПК."""
    try:
        from jnius import autoclass
        svc = autoclass('org.kivy.android.PythonService').mService
        if svc is not None:
            return svc
        return autoclass('org.kivy.android.PythonActivity').mActivity
    except Exception:
        return None


def data_dir() -> str:
    ctx = get_context()
    if ctx is not None:
        try:
            return ctx.getFilesDir().getAbsolutePath()
        except Exception:
            pass
    d = os.path.join(os.path.expanduser('~'), '.teamsautojoiner')
    os.makedirs(d, exist_ok=True)
    return d


def _read(name: str, default):
    try:
        with open(os.path.join(data_dir(), name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def _write(name: str, data):
    path = os.path.join(data_dir(), name)
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)          # атомарно — Java не увидит половину файла
    except Exception as e:
        log.error("запись %s: %s", name, e)


def load_lessons() -> dict:
    return _read('lessons.json', {})


def load_state() -> dict:
    return _read('state.json', {'joined': {}, 'events': [], 'synced_at': 0})


def save_state(state: dict):
    _write('state.json', state)


# ── Настройки ─────────────────────────────────────────────────────────────────

def clamp_buffer(value) -> int:
    """Буфер «пробуждения» в минутах: от MIN_BUFFER_MIN до MAX_BUFFER_MIN."""
    try:
        v = int(value)
    except (TypeError, ValueError):
        v = MIN_BUFFER_MIN
    return max(MIN_BUFFER_MIN, min(MAX_BUFFER_MIN, v))


def buffer_seconds(settings: dict) -> int:
    return clamp_buffer(settings.get('wake_buffer_minutes', MIN_BUFFER_MIN)) * 60


def lesson_length(settings: dict) -> int:
    try:
        return max(1, int(settings.get('lesson_duration_minutes', 45)))
    except (TypeError, ValueError):
        return 45


# ── Имена и ссылки ────────────────────────────────────────────────────────────

def norm_name(s) -> str:
    """Название для сравнения: регистр, «ё», знаки препинания и пробелы не важны."""
    s = str(s or '').lower().replace('ё', 'е')
    s = re.sub(r'[^\w\s]', ' ', s)
    return ' '.join(s.split())


def extract_teams_url(*texts) -> str:
    for t in texts:
        if not t:
            continue
        m = TEAMS_URL_RE.search(str(t).replace('&amp;', '&'))
        if m:
            return m.group(0).rstrip('.,;')
    return ''


def _valid_time(s) -> bool:
    try:
        h, m = map(int, str(s).split(':'))
        return 0 <= h <= 23 and 0 <= m <= 59
    except (ValueError, TypeError):
        return False


# ── Google Календарь (через календарь телефона) ──────────────────────────────

def has_calendar_permission() -> bool:
    try:
        from android.permissions import check_permission, Permission
        return bool(check_permission(Permission.READ_CALENDAR))
    except Exception:
        return False


def request_calendar_permission(callback=None):
    try:
        from android.permissions import request_permissions, Permission
        request_permissions([Permission.READ_CALENDAR], callback)
    except Exception as e:
        log.warning("запрос READ_CALENDAR: %s", e)


def _holiday_calendar_ids(resolver) -> set:
    """ID календарей праздников и каникул (Google «праздники» и т.п.)."""
    out = set()
    try:
        from jnius import autoclass
        Calendars = autoclass('android.provider.CalendarContract$Calendars')
        cur = resolver.query(Calendars.CONTENT_URI,
                             ['_id', 'name', 'calendar_displayName'], None, None, None)
        if cur is None:
            return out
        try:
            while cur.moveToNext():
                name = (cur.getString(1) or '').lower()
                disp = cur.getString(2) or ''
                if '#holiday@' in name or HOLIDAY_RE.search(disp):
                    out.add(cur.getLong(0))
        finally:
            cur.close()
    except Exception as e:
        log.warning("календари праздников: %s", e)
    return out


def fetch_calendar_events(days_ahead: int = 7) -> list:
    """
    События со ссылкой Teams на ближайшие N дней.
    Пропускаются: весь день, отклонённые и отменённые, календари и названия
    праздников/каникул. Дубли (одно название и время в нескольких календарях) — один раз.
    """
    ctx = get_context()
    if ctx is None or not has_calendar_permission():
        return []
    try:
        from jnius import autoclass
        Instances = autoclass('android.provider.CalendarContract$Instances')
        resolver = ctx.getContentResolver()

        now = datetime.now()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=days_ahead)
        b_ms, e_ms = int(start.timestamp() * 1000), int(end.timestamp() * 1000)

        # 0 event_id, 1 title, 2 begin, 3 end, 4 description, 5 eventLocation,
        # 6 allDay, 7 eventStatus, 8 selfAttendeeStatus, 9 calendar_id
        proj = ['event_id', 'title', 'begin', 'end', 'description', 'eventLocation',
                'allDay', 'eventStatus', 'selfAttendeeStatus', 'calendar_id']
        skip_cals = _holiday_calendar_ids(resolver)
        cur = Instances.query(resolver, proj, b_ms, e_ms)
        events, seen = [], set()
        if cur is None:
            return events
        try:
            while cur.moveToNext():
                title = cur.getString(1) or ''
                if cur.getInt(6) == 1:                                   # весь день
                    continue
                if cur.getInt(7) == STATUS_CANCELED:                      # отменено
                    continue
                if cur.getInt(8) == ATTENDEE_DECLINED:                    # я отклонил
                    continue
                if cur.getLong(9) in skip_cals or HOLIDAY_RE.search(title):
                    continue
                url = extract_teams_url(cur.getString(4), cur.getString(5))
                if not url:
                    continue
                begin, finish = cur.getLong(2), cur.getLong(3)
                key = (norm_name(title), begin // 60000)
                if key in seen:                                           # дубль из другого календаря
                    continue
                seen.add(key)
                events.append({
                    'key':   f"{cur.getLong(0)}_{begin}",
                    'name':  title or 'Урок',
                    'url':   url,
                    'begin': begin,
                    'end':   finish,
                })
        finally:
            cur.close()
        events.sort(key=lambda e: e['begin'])
        return events
    except Exception as e:
        log.warning("fetch_calendar_events: %s", e)
        return []


def sync_calendar(force: bool = False, every_sec: int = 900) -> list:
    """Обновляет state['events'] не чаще раза в 15 минут (или принудительно)."""
    state = load_state()
    if not force and time.time() - state.get('synced_at', 0) < every_sec:
        return state.get('events', [])
    events = fetch_calendar_events()
    state = load_state()
    if events or has_calendar_permission():
        state['events'] = events
    state['synced_at'] = time.time()
    save_state(state)
    log.info("календарь: %d событий со ссылкой Teams", len(events))
    return events


# ── Расписание: даты, пропуски, сессии ───────────────────────────────────────

def _occurrences(lesson: dict, now: datetime, days_ahead: int = 14):
    """Даты начала урока (без учёта пропусков), начиная с now, по возрастанию."""
    if not _valid_time(lesson.get('time')):
        return
    h, m = map(int, lesson['time'].split(':'))
    days = set(lesson.get('days') or range(7))
    for d in range(days_ahead + 1):
        day = now.date() + timedelta(days=d)
        if day.weekday() in days:
            dt = datetime(day.year, day.month, day.day, h, m)
            if dt > now:
                yield dt


def next_occurrence(lesson: dict, now: datetime, ignore_skips: bool = False):
    """Ближайший запуск урока (datetime) или None. Пропущенные даты пропускаются."""
    skips = set(lesson.get('skip_dates', []))
    for dt in _occurrences(lesson, now):
        if ignore_skips or dt.date().isoformat() not in skips:
            return dt
    return None


def next_occurrence_skipped(lesson: dict, now: datetime) -> bool:
    dt = next_occurrence(lesson, now, ignore_skips=True)
    return dt is not None and dt.date().isoformat() in set(lesson.get('skip_dates', []))


def toggle_skip_next(lesson: dict, now: datetime) -> bool:
    """Пропускает ближайший запуск или возвращает уже пропущенный. True — теперь пропущен."""
    dt = next_occurrence(lesson, now, ignore_skips=True)
    if dt is None:
        return False
    key = dt.date().isoformat()
    skips = {d for d in lesson.get('skip_dates', []) if d >= now.date().isoformat()}
    if key in skips:
        skips.discard(key)
        lesson['skip_dates'] = sorted(skips)
        return False
    skips.add(key)
    lesson['skip_dates'] = sorted(skips)
    return True


def _is_duplicate(name, start_ms, events) -> bool:
    """Урок из расписания совпадает с событием календаря (то же название, ±10 мин)."""
    n = norm_name(name)
    return any(norm_name(ev.get('name')) == n and abs(ev['begin'] - start_ms) <= DUP_TOL_MS
               for ev in events)


def sessions_between(settings: dict, data: dict, state: dict, lo: float, hi: float,
                     now=None) -> list:
    """
    Сессии, у которых начало в интервале [lo, hi] секунд от «сейчас».
    Календарь приоритетнее: урок из расписания с тем же названием и временем пропускается.
    Пропущенные даты (skip_dates) и выключенные уроки не возвращаются.
    """
    now = now or datetime.now()
    now_s = now.timestamp()
    default_len = lesson_length(settings)
    events = state.get('events', [])
    out = []

    for ev in events:
        diff = ev['begin'] / 1000 - now_s
        if lo <= diff <= hi:
            out.append({'id': 'cal_' + ev['key'], 'name': ev['name'], 'url': ev['url'],
                        'start_ms': ev['begin'], 'end_ms': ev['end'],
                        'mute_mic': True, 'mute_cam': True, 'source': 'calendar'})

    lessons = data.get('lessons', {})
    for off in range(int(lo // 86400) - 1, int(hi // 86400) + 2):
        day = now.date() + timedelta(days=off)
        for lesson in lessons.values():
            if not lesson.get('enabled', True) or not _valid_time(lesson.get('time')):
                continue
            if day.weekday() not in lesson.get('days', list(range(7))):
                continue
            if day.isoformat() in lesson.get('skip_dates', []):
                continue
            h, m = map(int, lesson['time'].split(':'))
            start_ms = int(datetime(day.year, day.month, day.day, h, m).timestamp() * 1000)
            diff = start_ms / 1000 - now_s
            if not (lo <= diff <= hi):
                continue
            if _is_duplicate(lesson.get('name', ''), start_ms, events):
                continue
            dur = int(lesson.get('duration_minutes') or default_len)
            out.append({'id': lesson['id'], 'name': lesson.get('name', 'Урок'),
                        'url': lesson.get('meeting_url', ''), 'start_ms': start_ms,
                        'end_ms': start_ms + dur * 60000,
                        'mute_mic': lesson.get('mute_mic', True),
                        'mute_cam': lesson.get('mute_camera', True),
                        'source': 'schedule'})
    return out


def due_sessions(settings: dict, data: dict, state: dict, now=None) -> list:
    """Пора входить: от буфера до начала и до 5 мин после начала."""
    return sessions_between(settings, data, state, -300, buffer_seconds(settings), now)


def next_lesson(settings: dict, data: dict, state: dict, now=None):
    now = now or datetime.now()
    upcoming = sessions_between(settings, data, state, 0, 7 * 86400, now)
    return min(upcoming, key=lambda s: s['start_ms']) if upcoming else None


def mark_joined(state: dict, session: dict) -> bool:
    """True, если сессия новая (и помечает её). Пропущенные уроки тоже помечаются."""
    stamp = str(session['start_ms'])
    joined = state.setdefault('joined', {})
    if joined.get(session['id']) == stamp:
        return False
    joined[session['id']] = stamp
    cutoff = (time.time() - 172800) * 1000
    state['joined'] = {k: v for k, v in joined.items() if v.isdigit() and int(v) > cutoff}
    return True


def already_handled(state: dict, session: dict) -> bool:
    return state.get('joined', {}).get(session['id']) == str(session['start_ms'])


# ── Пересечения и дубли в расписании ──────────────────────────────────────────

def _span(lesson, default_len):
    h, m = map(int, lesson['time'].split(':'))
    start = h * 60 + m
    return start, start + int(lesson.get('duration_minutes') or default_len)


def _days_of(lesson) -> set:
    return set(lesson.get('days') or range(7))


def find_overlaps(lessons: dict, cand: dict, default_len: int) -> list:
    """Названия уроков, которые пересекаются по времени с кандидатом (общие дни)."""
    if not _valid_time(cand.get('time')):
        return []
    s1, e1 = _span(cand, default_len)
    out = []
    for l in lessons.values():
        if l.get('id') == cand.get('id') or not l.get('enabled', True):
            continue
        if not _valid_time(l.get('time')):
            continue
        s2, e2 = _span(l, default_len)
        if _days_of(cand) & _days_of(l) and s1 < e2 and s2 < e1:
            out.append(l.get('name', 'Урок'))
    return out


def find_duplicate(lessons: dict, cand: dict):
    """Урок с тем же названием, временем и общим днём (или None)."""
    n = norm_name(cand.get('name'))
    for l in lessons.values():
        if l.get('id') == cand.get('id'):
            continue
        if (norm_name(l.get('name')) == n and l.get('time') == cand.get('time')
                and _days_of(l) & _days_of(cand)):
            return l
    return None


# ── Импорт расписания ─────────────────────────────────────────────────────────

def _cut(text, spans):
    out, last = [], 0
    for s, e in sorted(spans):
        if s < last:
            continue
        out.append(text[last:s])
        out.append(' ')
        last = e
    out.append(text[last:])
    return ''.join(out)


def _extract_days(text):
    """Дни недели из строки: «Пн Ср» или «Пн-Пт». Возвращает (дни, текст без них)."""
    toks = list(WORD_RE.finditer(text))
    days, cuts = set(), []
    i = 0
    while i < len(toks):
        w = toks[i].group(0).lower()
        if w not in DAY_NAMES:
            i += 1
            continue
        a = DAY_NAMES[w]
        if (i + 1 < len(toks)
                and text[toks[i].end():toks[i + 1].start()].strip() in ('-', '–', '—')
                and toks[i + 1].group(0).lower() in DAY_NAMES):
            b = DAY_NAMES[toks[i + 1].group(0).lower()]
            days.update(range(min(a, b), max(a, b) + 1))
            cuts.append((toks[i].start(), toks[i + 1].end()))
            i += 2
            continue
        days.add(a)
        cuts.append(toks[i].span())
        i += 1
    return sorted(days), _cut(text, cuts)


def parse_schedule_text(text: str):
    """
    Разбирает расписание, по одному уроку в строке:
      «Математика Пн Ср 09:00-10:30 https://teams.microsoft.com/...»
      «Пн-Пт 14:00 Английский»
    Без дней — каждый день. Возвращает (уроки, ошибки).
    """
    lessons, errors = [], []
    for raw in text.splitlines():
        line = raw.strip().lstrip('•*-– ').strip()
        if not line:
            continue
        url_m = TEAMS_URL_RE.search(line)
        url = url_m.group(0).rstrip('.,;') if url_m else ''
        rest = TEAMS_URL_RE.sub(' ', line)

        dur = None
        m = TIME_RANGE_RE.search(rest)
        if m:
            h, mi, h2, m2 = (int(x) for x in m.groups())
            start = (h, mi)
            dur = (h2 * 60 + m2) - (h * 60 + mi) or None
        else:
            m = TIME_RE.search(rest)
            if not m:
                errors.append(f"нет времени: «{line}»")
                continue
            start = (int(m.group(1)), int(m.group(2)))
        if not (0 <= start[0] <= 23 and 0 <= start[1] <= 59):
            errors.append(f"неверное время: «{line}»")
            continue
        if dur is not None and dur <= 0:
            dur = None
        rest = rest[:m.start()] + ' ' + rest[m.end():]

        days, rest = _extract_days(rest)
        name = re.sub(r'\s+', ' ', rest).strip(' \t|,;:-–—.')
        if not name:
            errors.append(f"нет названия: «{line}»")
            continue
        lessons.append({
            'id':               str(uuid.uuid4()),
            'name':             name,
            'meeting_url':      url,
            'time':             f"{start[0]:02d}:{start[1]:02d}",
            'days':             days or list(range(7)),
            'mute_mic':         True,
            'mute_camera':      True,
            'enabled':          True,
            'duration_minutes': dur,
            'skip_dates':       [],
            'created_at':       datetime.now().isoformat(),
        })
    return lessons, errors


def export_lessons_json(data: dict) -> str:
    return json.dumps({
        'format': 'teams-autojoiner', 'version': 1,
        'lessons': list(data.get('lessons', {}).values()),
    }, ensure_ascii=False, indent=2)


def parse_lessons_json(text: str):
    """Импорт из JSON, созданного экспортом. Возвращает (уроки, ошибки)."""
    try:
        obj = json.loads(text)
    except ValueError:
        return [], ['не JSON']
    items = obj.get('lessons') if isinstance(obj, dict) else obj
    if not isinstance(items, list):
        return [], ['в файле нет списка уроков']
    lessons, errors = [], []
    for i, it in enumerate(items, 1):
        if not isinstance(it, dict):
            errors.append(f"урок {i}: не объект")
            continue
        name = str(it.get('name', '')).strip()
        if not name:
            errors.append(f"урок {i}: нет названия")
            continue
        if not _valid_time(it.get('time')):
            errors.append(f"«{name}»: неверное время")
            continue
        days = it.get('days') or list(range(7))
        if not (isinstance(days, list) and all(isinstance(d, int) and 0 <= d <= 6 for d in days)):
            errors.append(f"«{name}»: неверные дни")
            continue
        skips = []
        for d in it.get('skip_dates', []) or []:
            try:
                skips.append(date.fromisoformat(str(d)).isoformat())
            except ValueError:
                pass
        lessons.append({
            'id': str(uuid.uuid4()), 'name': name,
            'meeting_url': str(it.get('meeting_url', '') or ''),
            'time': it['time'], 'days': sorted(set(days)),
            'mute_mic': bool(it.get('mute_mic', True)),
            'mute_camera': bool(it.get('mute_camera', True)),
            'enabled': bool(it.get('enabled', True)),
            'duration_minutes': it.get('duration_minutes'),
            'skip_dates': sorted(set(skips)),
            'created_at': datetime.now().isoformat(),
        })
    return lessons, errors


# ── Связь с Java AccessibilityService ────────────────────────────────────────

def arm_accessibility(session: dict, leave_grace_sec: int = 0):
    """Сообщает AccessibilityService, когда жать «Присоединиться» и когда выходить."""
    now_ms = int(time.time() * 1000)
    _write('join_armed.json', {
        'id':        session['id'],
        'join_from': now_ms,
        'join_until': session['start_ms'] + 10 * 60000,   # ищем кнопку 10 мин
        'leave_at':  session['end_ms'] + leave_grace_sec * 1000,
        'mute_mic':  session.get('mute_mic', True),
        'mute_cam':  session.get('mute_cam', True),
    })


def disarm_accessibility():
    _write('join_armed.json', {})


def accessibility_enabled() -> bool:
    ctx = get_context()
    if ctx is None:
        return False
    try:
        from jnius import autoclass
        Secure = autoclass('android.provider.Settings$Secure')
        val = Secure.getString(ctx.getContentResolver(),
                               Secure.ENABLED_ACCESSIBILITY_SERVICES) or ''
        return 'TeamsAccessibilityService' in val
    except Exception:
        return False


def read_status() -> dict:
    return _read('a11y_status.json', {})


def _fmt_state(v) -> str:
    return {1: 'ВКЛ', 0: 'выкл'}.get(v, '?')


def describe_status(st: dict) -> str:
    return f"микрофон {_fmt_state(st.get('mic'))}, камера {_fmt_state(st.get('cam'))}"


def pop_action(now_ms=None):
    """
    Нажатие кнопки в уведомлении: {'action': 'join'|'skip', 'id': ...} или None.
    Действие старше ACTION_MAX_AGE_MS отбрасывается.
    """
    path = os.path.join(data_dir(), 'action.json')
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            act = json.load(f)
    except Exception:
        return None
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    now_ms = now_ms or int(time.time() * 1000)
    if not isinstance(act, dict) or now_ms - int(act.get('ts', 0)) > ACTION_MAX_AGE_MS:
        log.info("действие из уведомления устарело, пропускаю")
        return None
    return act


def request_lock():
    """Просит AccessibilityService заблокировать экран (Android 9+)."""
    _write('lock_request.json', {'ts': int(time.time() * 1000)})


# ── Сеть ──────────────────────────────────────────────────────────────────────

def network_status() -> str:
    """
    'wifi' | 'cellular' | 'other' — интернет есть;
    'no_internet' — сеть есть, интернета нет; 'no_network' — сети нет вовсе;
    'unknown' — проверка не удалась.
    На ПК всегда 'wifi' (проверка не нужна).
    """
    ctx = get_context()
    if ctx is None:
        return 'wifi'
    try:
        from jnius import autoclass
        Context = autoclass('android.content.Context')
        NC = autoclass('android.net.NetworkCapabilities')
        cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE)
        net = cm.getActiveNetwork()
        if net is None:
            return 'no_network'
        caps = cm.getNetworkCapabilities(net)
        if caps is None:
            return 'no_network'
        if not (caps.hasCapability(NC.NET_CAPABILITY_INTERNET)
                and caps.hasCapability(NC.NET_CAPABILITY_VALIDATED)):
            return 'no_internet'
        if caps.hasTransport(NC.TRANSPORT_WIFI):
            return 'wifi'
        if caps.hasTransport(NC.TRANSPORT_CELLULAR):
            return 'cellular'
        return 'other'
    except Exception as e:
        log.warning("network_status: %s", e)
        return 'unknown'                  # не знаем — не предупреждаем и не врём


def net_problem(settings: dict, net: str) -> str:
    """Текст предупреждения о сети или '' если всё в порядке."""
    if net in ('no_internet', 'no_network'):
        return NET_TEXT[net]
    if net == 'cellular' and settings.get('warn_no_wifi', False):
        return NET_TEXT['cellular']
    return ''


# ── Уведомления ───────────────────────────────────────────────────────────────

def notify(title: str, text: str, sid: str = '', actions: bool = False):
    """Уведомление. С actions=True добавляет кнопки «Войти сейчас» и «Пропустить»."""
    ctx = get_context()
    if ctx is None:
        log.info("уведомление: %s — %s", title, text)
        return
    try:
        from jnius import autoclass
        H = autoclass(_NOTIFY_CLS)
        nid = zlib.crc32((sid or title).encode('utf-8')) % 100000 + 100
        H.show(ctx, nid, title, text, sid or '', bool(actions))
    except Exception as e:
        log.warning("notify: %s", e)


# ── «Не беспокоить» на время урока ───────────────────────────────────────────
# Звонок телефона не меняем. Запоминаем прежний режим «Не беспокоить»
# (в том числе тот, что пользователь включил сам) и возвращаем его после урока.

def _nm():
    ctx = get_context()
    if ctx is None:
        return None
    from jnius import autoclass
    Context = autoclass('android.content.Context')
    return ctx.getSystemService(Context.NOTIFICATION_SERVICE)


def dnd_access() -> bool:
    """Выдан ли доступ к режиму «Не беспокоить» (Notification Policy Access)."""
    try:
        nm = _nm()
        return bool(nm is not None and nm.isNotificationPolicyAccessGranted())
    except Exception:
        return False


def enter_quiet(settings: dict, state: dict):
    if not settings.get('dnd_during_lesson', True) or 'saved_dnd' in state:
        return
    try:
        if not dnd_access():
            return
        from jnius import autoclass
        NM = autoclass('android.app.NotificationManager')
        nm = _nm()
        state['saved_dnd'] = int(nm.getCurrentInterruptionFilter())
        nm.setInterruptionFilter(NM.INTERRUPTION_FILTER_ALARMS)
        log.info("«Не беспокоить» включено на время урока")
    except Exception as e:
        log.warning("enter_quiet: %s", e)


def leave_quiet(settings: dict, state: dict):
    """После урока возвращает прежний режим «Не беспокоить» (звук снова слышно)."""
    saved = state.pop('saved_dnd', None)
    if saved is None:
        return
    try:
        if dnd_access():
            _nm().setInterruptionFilter(int(saved))
            log.info("«Не беспокоить» возвращено в прежний режим")
    except Exception as e:
        log.warning("leave_quiet: %s", e)


# ── Будильники (надёжность в Doze) ───────────────────────────────────────────

_ALARM_CLS = 'org.student.teams.teamsautojoiner.AlarmReceiver'


def _upcoming_starts(settings: dict, lessons: dict, state: dict, days: int = 7) -> list:
    now = datetime.now()
    out = {ev['begin'] for ev in state.get('events', [])}
    for lesson in lessons.get('lessons', {}).values():
        if not lesson.get('enabled', True) or not _valid_time(lesson.get('time')):
            continue
        h, m = map(int, lesson['time'].split(':'))
        for d in range(days + 1):
            day = now + timedelta(days=d)
            if day.weekday() in lesson.get('days', list(range(7))) \
                    and day.date().isoformat() not in lesson.get('skip_dates', []):
                out.add(int(day.replace(hour=h, minute=m, second=0,
                                        microsecond=0).timestamp() * 1000))
    return sorted(out)


def schedule_alarms(settings: dict, lessons: dict, state: dict, max_n: int = 12):
    """setAlarmClock на (начало − буфер) для ближайших уроков и keep-alive каждые 15 мин."""
    ctx = get_context()
    if ctx is None:
        return
    try:
        from jnius import autoclass
        AlarmManager  = autoclass('android.app.AlarmManager')
        PendingIntent = autoclass('android.app.PendingIntent')
        Intent        = autoclass('android.content.Intent')
        Context       = autoclass('android.content.Context')
        Info          = autoclass('android.app.AlarmManager$AlarmClockInfo')

        am  = ctx.getSystemService(Context.ALARM_SERVICE)
        pkg = ctx.getPackageName()
        flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE

        def pi(code):
            i = Intent()
            i.setClassName(pkg, _ALARM_CLS)
            return PendingIntent.getBroadcast(ctx, code, i, flags)

        show = PendingIntent.getActivity(
            ctx, 0, ctx.getPackageManager().getLaunchIntentForPackage(pkg), flags)

        now_ms = int(time.time() * 1000)
        lead = (buffer_seconds(settings) + 20) * 1000
        n = 0
        for start in _upcoming_starts(settings, lessons, state):
            t = start - lead
            if t <= now_ms + 2000:
                continue
            code = int(t // 60000) % 2000000000 + 10
            am.setAlarmClock(Info(t, show), pi(code))
            n += 1
            if n >= max_n:
                break
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, now_ms + 15 * 60000, pi(1))
        log.info("будильников поставлено: %d", n)
    except Exception as e:
        log.warning("schedule_alarms: %s", e)


# ── Здоровье автоматизации (для главного экрана) ─────────────────────────────

def health() -> dict:
    """Состояние разрешений и служб. На ПК все значения None (не проверяется)."""
    if get_context() is None:
        return {'a11y': None, 'calendar': None, 'dnd': None}
    return {'a11y': accessibility_enabled(),
            'calendar': has_calendar_permission(),
            'dnd': dnd_access()}


# ── Виджет на рабочем столе ───────────────────────────────────────────────────

def when_text(start_dt: datetime, now: datetime) -> str:
    d = (start_dt.date() - now.date()).days
    t = start_dt.strftime('%H:%M')
    if d == 0:
        return f"Сегодня в {t}"
    if d == 1:
        return f"Завтра в {t}"
    return f"{DAYS_FULL[start_dt.weekday()]} в {t}"


def build_widget_state(settings: dict, data: dict, state: dict, now=None) -> dict:
    now = now or datetime.now()
    if not settings.get('automation_enabled', True):
        status = '⏸ Автоматизация выключена'
    else:
        net = network_status()
        problem = net_problem(settings, net)
        status = f"⚠️ {problem}" if problem else '✅ Автоматизация включена'
    nxt = next_lesson(settings, data, state, now)
    if nxt:
        return {'title': nxt['name'],
                'when': when_text(datetime.fromtimestamp(nxt['start_ms'] / 1000), now),
                'status': status}
    return {'title': 'Уроков нет', 'when': 'Добавь расписание в приложении', 'status': status}


def push_widget(data: dict):
    """Пишет данные виджета и будит его, только если содержимое изменилось."""
    global _last_widget
    if data == _last_widget:
        return
    _last_widget = data
    _write('widget.json', data)
    ctx = get_context()
    if ctx is None:
        return
    try:
        from jnius import autoclass
        AppWidgetManager = autoclass('android.appwidget.AppWidgetManager')
        Intent = autoclass('android.content.Intent')
        i = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
        i.setClassName(ctx.getPackageName(), _WIDGET_CLS)
        ctx.sendBroadcast(i)
    except Exception as e:
        log.warning("push_widget: %s", e)


# ── Ссылка из Teams через меню «Поделиться» ───────────────────────────────────

SHARE_ACTION = 'android.intent.action.SEND'
SHARE_EXTRA_TEXT = 'android.intent.extra.TEXT'


def share_text_from_intent(intent):
    """Текст, которым поделились (или None). intent — объект Android Intent или None."""
    try:
        if intent is None or intent.getAction() != SHARE_ACTION:
            return None
        text = intent.getStringExtra(SHARE_EXTRA_TEXT)
        return str(text) if text else None
    except Exception as e:
        log.warning("share_text_from_intent: %s", e)
        return None


def clear_share_intent(activity):
    """Сбрасывает намерение, чтобы та же ссылка не обработалась дважды."""
    try:
        from jnius import autoclass
        Intent = autoclass('android.content.Intent')
        activity.setIntent(Intent())
    except Exception as e:
        log.warning("clear_share_intent: %s", e)


def apply_share(lessons: dict, url: str, lesson_id: str, all_same_name: bool = False) -> int:
    """
    Сохраняет ссылку в выбранный урок. С all_same_name=True — во все уроки
    с таким же названием (например, алгебра в разные дни). Возвращает число уроков.
    """
    target = lessons.get(lesson_id)
    if not target:
        return 0
    name = norm_name(target.get('name'))
    count = 0
    for l in lessons.values():
        if l['id'] == lesson_id or (all_same_name and norm_name(l.get('name')) == name):
            l['meeting_url'] = url
            count += 1
    return count
