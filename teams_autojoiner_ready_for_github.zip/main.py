"""
Teams Auto-Joiner v1.3.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Автоматически входит на уроки Microsoft Teams по расписанию.
Пробуждает телефон, открывает Teams и заходит на урок с
выключенным микрофоном и камерой.

Запуск на ПК (тест):
    pip install kivy kivymd
    python main.py

Сборка APK:
    pip install buildozer
    buildozer android debug
"""

__version__ = "1.4.0"

import os
import uuid
import json
import logging
from datetime import datetime, timedelta

from kivy.clock import Clock
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import BooleanProperty
from kivy.utils import platform
from kivy.uix.behaviors import ButtonBehavior
from kivy.core.window import Window

from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton, MDFloatingActionButton
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.snackbar import Snackbar
from kivymd.uix.selectioncontrol import MDSwitch

import core

log = logging.getLogger('tja')

# ── Константы ─────────────────────────────────────────────────────────────────

DAYS_SHORT = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
DAYS_FULL  = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье']
MONTHS_RU  = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня',
              'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря']

DEFAULT_SETTINGS = {
    'automation_enabled': True,
    'wake_buffer_minutes': 1,
    'lesson_duration_minutes': 45,
    'calendar_sync': True,
    'dark_theme': True,
    'dnd_during_lesson': True,
    'warn_no_wifi': False,
    'lock_after_lesson': True,
}

# ── KV-разметка ───────────────────────────────────────────────────────────────

KV = """
#:import dp kivy.metrics.dp
#:import MDSwitch kivymd.uix.selectioncontrol.MDSwitch

# Корень приложения: все экраны лежат в менеджере
ScreenManager:
    HomeScreen:
    AddLessonScreen:
    ImportScreen:
    ShareScreen:
    SettingsScreen:

# ── Адаптивные базовые виджеты ────────────────────────────────────────────────
# Высоты считаются по содержимому: подписи переносятся на узких экранах.

<WrapLabel@MDLabel>:
    size_hint_y: None
    text_size: self.width, None
    height: self.texture_size[1]

<RowLabel@WrapLabel>:
    pos_hint: {'center_y': .5}

<TwoLine@MDBoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    adaptive_height: True
    pos_hint: {'center_y': .5}

<Row@MDBoxLayout>:
    size_hint_y: None
    height: max(self.minimum_height, dp(48))
    spacing: dp(8)

<SCard@MDCard>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: dp(16)
    spacing: dp(8)
    elevation: 1
    radius: [dp(12)]

# Колонка контента: на планшетах не шире 560 dp и по центру
<Page@MDBoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    spacing: dp(12)
    padding: [max(dp(16), (self.width - dp(560)) / 2), dp(16), max(dp(16), (self.width - dp(560)) / 2), dp(32)]

# ── Главный экран ─────────────────────────────────────────────────────────────
<HomeScreen>:
    name: 'home'

    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: '📅  Teams Расписание'
            md_bg_color: app.theme_cls.primary_color
            right_action_items:
                [['file-import-outline', lambda x: app.go_screen("import")], ['cog', lambda x: app.go_screen("settings"), 'Настройки']]
            elevation: 4

        MDBoxLayout:
            orientation: 'vertical'
            padding: [max(dp(12), (self.width - dp(560)) / 2), dp(10), max(dp(12), (self.width - dp(560)) / 2), 0]
            spacing: dp(10)

            SCard:
                elevation: 2
                radius: [dp(14)]
                padding: [dp(16), dp(10)]

                MDBoxLayout:
                    size_hint_y: None
                    adaptive_height: True
                    spacing: dp(14)

                    WrapLabel:
                        id: status_emoji
                        text: "✅"
                        font_size: "26sp"
                        size_hint_x: None
                        width: dp(36)
                        halign: 'center'
                        pos_hint: {'center_y': .5}

                    TwoLine:
                        WrapLabel:
                            id: status_label
                            text: "Автоматизация включена"
                            font_style: "Subtitle2"
                            bold: True
                        WrapLabel:
                            id: date_label
                            text: ""
                            font_style: "Caption"
                            theme_text_color: "Secondary"
                        WrapLabel:
                            id: health_label
                            text: ""
                            font_style: "Caption"
                            theme_text_color: "Hint"

            WrapLabel:
                text: "МОИ УРОКИ"
                font_style: "Overline"
                theme_text_color: "Secondary"

            ScrollView:
                MDList:
                    id: lessons_list
                    spacing: dp(8)
                    padding: [0, 0, 0, dp(88)]

    MDFloatingActionButton:
        icon: 'plus'
        pos_hint: {'right': .94, 'y': .03}
        md_bg_color: app.theme_cls.primary_color
        elevation: 6
        on_release: app.go_screen("add_lesson")

# ── Экран добавления урока ────────────────────────────────────────────────────
<AddLessonScreen>:
    name: 'add_lesson'

    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            id: add_toolbar
            title: 'Новый урок'
            md_bg_color: app.theme_cls.primary_color
            left_action_items:
                [['arrow-left', lambda x: app.go_screen("home")]]
            elevation: 4

        ScrollView:
            Page:
                spacing: dp(16)

                MDTextField:
                    id: name_field
                    hint_text: "Название урока (напр. Математика)"
                    icon_left: "book-open-variant"
                    mode: "rectangle"
                    size_hint_y: None
                    height: dp(64)

                MDTextField:
                    id: url_field
                    hint_text: "Ссылка Teams (необязательно)"
                    icon_left: "link-variant"
                    mode: "rectangle"
                    size_hint_y: None
                    height: dp(64)

                SCard:
                    WrapLabel:
                        text: "⏰  Время начала урока"
                        font_style: "Subtitle2"
                        bold: True

                    Row:
                        spacing: dp(6)

                        MDTextField:
                            id: hour_field
                            hint_text: "ЧЧ"
                            input_filter: "int"
                            mode: "rectangle"
                            max_text_length: 2
                            size_hint: None, None
                            size: dp(72), dp(56)
                            halign: "center"

                        MDLabel:
                            text: ":"
                            font_style: "H5"
                            halign: "center"
                            size_hint: None, None
                            size: dp(20), dp(56)

                        MDTextField:
                            id: minute_field
                            hint_text: "ММ"
                            input_filter: "int"
                            mode: "rectangle"
                            max_text_length: 2
                            size_hint: None, None
                            size: dp(72), dp(56)
                            halign: "center"

                        Widget:

                SCard:
                    WrapLabel:
                        text: "📆  Дни недели"
                        font_style: "Subtitle2"
                        bold: True

                    MDBoxLayout:
                        id: days_container
                        size_hint_y: None
                        height: dp(44)
                        spacing: dp(4)

                SCard:
                    WrapLabel:
                        text: "🔇  Параметры подключения"
                        font_style: "Subtitle2"
                        bold: True

                    Row:
                        RowLabel:
                            text: "Выключить микрофон при входе"
                            font_style: "Body2"
                        MDSwitch:
                            id: mute_mic_sw
                            active: True
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}

                    Row:
                        RowLabel:
                            text: "Выключить камеру при входе"
                            font_style: "Body2"
                        MDSwitch:
                            id: mute_cam_sw
                            active: True
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}

                MDBoxLayout:
                    size_hint_y: None
                    height: dp(48)
                    spacing: dp(12)

                    MDFlatButton:
                        text: "ОТМЕНА"
                        on_release: app.go_screen("home")
                        size_hint: .4, 1

                    MDRaisedButton:
                        id: save_btn
                        text: "СОХРАНИТЬ"
                        md_bg_color: app.theme_cls.primary_color
                        on_release: app.save_lesson()
                        size_hint: .6, 1

# ── Экран импорта расписания ──────────────────────────────────────────────────
<ImportScreen>:
    name: 'import'

    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: 'Импорт расписания'
            md_bg_color: app.theme_cls.primary_color
            left_action_items:
                [['arrow-left', lambda x: app.go_screen("home")]]
            elevation: 4

        ScrollView:
            Page:

                SCard:
                    WrapLabel:
                        text: "Вставь расписание, по одному уроку в строке. Дни и время можно писать в любом порядке."
                        font_style: "Body2"
                    WrapLabel:
                        text: "Математика Пн Ср 09:00-10:30 https://teams.microsoft.com/l/meetup-join/..."
                        font_style: "Caption"
                        theme_text_color: "Secondary"
                    WrapLabel:
                        text: "Пн-Пт 14:00 Английский"
                        font_style: "Caption"
                        theme_text_color: "Secondary"

                MDTextField:
                    id: import_field
                    hint_text: "Расписание"
                    multiline: True
                    mode: "rectangle"
                    size_hint_y: None
                    height: dp(220)

                MDRaisedButton:
                    text: "РАЗОБРАТЬ"
                    md_bg_color: app.theme_cls.primary_color
                    size_hint: 1, None
                    height: dp(48)
                    on_release: app.parse_import()

# ── Экран «Поделиться из Teams» ───────────────────────────────────────────────
<ShareScreen>:
    name: 'share'

    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: 'Ссылка из Teams'
            md_bg_color: app.theme_cls.primary_color
            left_action_items:
                [['arrow-left', lambda x: app.cancel_share()]]
            elevation: 4

        ScrollView:
            Page:

                SCard:
                    WrapLabel:
                        id: share_url_label
                        text: ""
                        font_style: "Body2"
                    Row:
                        RowLabel:
                            text: "Сохранить во все уроки с таким же названием"
                            font_style: "Body2"
                        MDSwitch:
                            id: share_all_sw
                            active: False
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}

                WrapLabel:
                    text: "Выберите урок"
                    font_style: "Overline"
                    theme_text_color: "Secondary"

                MDBoxLayout:
                    id: share_list
                    orientation: 'vertical'
                    size_hint_y: None
                    adaptive_height: True
                    spacing: dp(8)

                MDFlatButton:
                    text: "НОВЫЙ УРОК С ЭТОЙ ССЫЛКОЙ"
                    size_hint: 1, None
                    height: dp(48)
                    on_release: app.share_new_lesson()

# ── Экран настроек ────────────────────────────────────────────────────────────
<SettingsScreen>:
    name: 'settings'

    MDBoxLayout:
        orientation: 'vertical'

        MDTopAppBar:
            title: '⚙️  Настройки'
            md_bg_color: app.theme_cls.primary_color
            left_action_items:
                [['arrow-left', lambda x: app.go_screen("home")]]
            elevation: 4

        ScrollView:
            Page:

                SCard:
                    elevation: 2
                    Row:
                        TwoLine:
                            WrapLabel:
                                text: "Автоматизация"
                                font_style: "Subtitle1"
                                bold: True
                            WrapLabel:
                                text: "Автоматически входить на уроки"
                                font_style: "Caption"
                                theme_text_color: "Secondary"
                        MDSwitch:
                            id: auto_sw
                            active: True
                            pos_hint: {'center_y': .5}
                            size_hint_x: None
                            width: dp(60)
                            on_active: app.toggle_automation(self.active)

                SCard:
                    Row:
                        RowLabel:
                            text: "Тёмная тема"
                            font_style: "Subtitle1"
                            bold: True
                        MDSwitch:
                            id: theme_sw
                            active: True
                            pos_hint: {'center_y': .5}
                            size_hint_x: None
                            width: dp(60)
                            on_active: app.toggle_theme(self.active)

                SCard:
                    WrapLabel:
                        text: "Пробудить экран заранее"
                        font_style: "Subtitle1"
                        bold: True
                    Row:
                        MDTextField:
                            id: buffer_field
                            text: "1"
                            hint_text: "мин."
                            input_filter: "int"
                            mode: "rectangle"
                            max_text_length: 2
                            size_hint: None, None
                            size: dp(76), dp(52)
                            on_text: app.update_buffer(self.text)
                        RowLabel:
                            text: "минут до начала урока"
                            font_style: "Body2"

                SCard:
                    WrapLabel:
                        text: "Авто-выход из урока"
                        font_style: "Subtitle1"
                        bold: True
                    Row:
                        MDTextField:
                            id: duration_field
                            text: "45"
                            hint_text: "мин."
                            input_filter: "int"
                            mode: "rectangle"
                            max_text_length: 3
                            size_hint: None, None
                            size: dp(84), dp(52)
                            on_text: app.update_duration(self.text)
                        RowLabel:
                            text: "минут. Для уроков из календаря берётся время конца события"
                            font_style: "Caption"
                            theme_text_color: "Secondary"

                SCard:
                    WrapLabel:
                        text: "🔕  Тишина во время урока (возвращает прежний режим «Не беспокоить»)"
                        font_style: "Subtitle1"
                        bold: True
                    Row:
                        RowLabel:
                            text: "Включать «Не беспокоить» на время урока"
                            font_style: "Body2"
                        MDSwitch:
                            id: dnd_sw
                            active: True
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}
                            on_active: app.set_flag('dnd_during_lesson', self.active)
                    Row:
                        RowLabel:
                            text: "Предупреждать, если работает не Wi-Fi"
                            font_style: "Body2"
                        MDSwitch:
                            id: wifi_sw
                            active: False
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}
                            on_active: app.set_flag('warn_no_wifi', self.active)
                    Row:
                        RowLabel:
                            text: "После урока блокировать экран (Android 9+)"
                            font_style: "Body2"
                        MDSwitch:
                            id: lock_sw
                            active: True
                            size_hint_x: None
                            width: dp(60)
                            pos_hint: {'center_y': .5}
                            on_active: app.set_flag('lock_after_lesson', self.active)
                    MDRaisedButton:
                        text: "Доступ к «Не беспокоить»"
                        size_hint: 1, None
                        height: dp(44)
                        on_release: app.open_dnd_access()

                SCard:
                    Row:
                        RowLabel:
                            text: "📆  Ссылки из Google Календаря"
                            font_style: "Subtitle1"
                            bold: True
                        MDSwitch:
                            id: cal_sw
                            active: True
                            pos_hint: {'center_y': .5}
                            size_hint_x: None
                            width: dp(60)
                            on_active: app.set_flag('calendar_sync', self.active)
                    WrapLabel:
                        id: cal_status
                        text: ""
                        font_style: "Caption"
                        theme_text_color: "Secondary"
                    MDRaisedButton:
                        text: "Обновить сейчас"
                        size_hint: 1, None
                        height: dp(44)
                        on_release: app.sync_calendar_now()

                SCard:
                    WrapLabel:
                        text: "🔒  Разрешения Android"
                        font_style: "Subtitle1"
                        bold: True
                    Row:
                        RowLabel:
                            text: "Поверх других приложений"
                            font_style: "Body2"
                        MDRaisedButton:
                            text: "Дать"
                            size_hint: None, None
                            size: dp(96), dp(40)
                            pos_hint: {'center_y': .5}
                            on_release: app.req_overlay()
                    Row:
                        RowLabel:
                            text: "Игнорировать оптимизацию батареи"
                            font_style: "Body2"
                        MDRaisedButton:
                            text: "Дать"
                            size_hint: None, None
                            size: dp(96), dp(40)
                            pos_hint: {'center_y': .5}
                            on_release: app.req_battery()
                    Row:
                        RowLabel:
                            id: a11y_label
                            text: "Специальные возможности"
                            font_style: "Body2"
                        MDRaisedButton:
                            text: "Открыть"
                            size_hint: None, None
                            size: dp(96), dp(40)
                            pos_hint: {'center_y': .5}
                            on_release: app.open_accessibility()
                    Row:
                        RowLabel:
                            id: dnd_label
                            text: "Не беспокоить"
                            font_style: "Body2"
                    Row:
                        RowLabel:
                            text: "Календарь (чтение)"
                            font_style: "Body2"
                        MDRaisedButton:
                            text: "Дать"
                            size_hint: None, None
                            size: dp(96), dp(40)
                            pos_hint: {'center_y': .5}
                            on_release: app.req_calendar()

                SCard:
                    WrapLabel:
                        text: "💾  Расписание"
                        font_style: "Subtitle1"
                        bold: True
                    WrapLabel:
                        text: "Копирует все уроки в буфер обмена (JSON). Вставить можно на экран импорта."
                        font_style: "Caption"
                        theme_text_color: "Secondary"
                    MDRaisedButton:
                        text: "Скопировать расписание"
                        size_hint: 1, None
                        height: dp(44)
                        on_release: app.export_lessons()

                SCard:
                    WrapLabel:
                        text: "🛠  Диагностика"
                        font_style: "Subtitle1"
                        bold: True
                    WrapLabel:
                        text: "Если кнопка или микрофон не находятся: открой Teams на экране звонка, подожди 5 с, нажми кнопку и пришли текст"
                        font_style: "Caption"
                        theme_text_color: "Secondary"
                    MDRaisedButton:
                        text: "Скопировать дамп экрана Teams"
                        size_hint: 1, None
                        height: dp(44)
                        on_release: app.copy_dump()

                SCard:
                    WrapLabel:
                        text: "Teams Auto-Joiner  v1.3.0"
                        font_style: "Subtitle2"
                        bold: True
                        halign: "center"
                    WrapLabel:
                        text: "Автоматически входи на уроки Teams"
                        font_style: "Caption"
                        theme_text_color: "Secondary"
                        halign: "center"
"""


# ── Кнопка-тоггл для дня недели ───────────────────────────────────────────────

def norm_name_for_ui(name) -> str:
    return core.norm_name(name)


class DayToggleButton(ButtonBehavior, MDBoxLayout):
    """Кнопка дня недели: все 7 делят ширину поровну."""

    is_selected = BooleanProperty(False)

    def __init__(self, day_index: int, day_name: str, **kwargs):
        super().__init__(**kwargs)
        self.day_index = day_index
        self.size_hint = (1, None)
        self.height = dp(44)
        self.radius = [dp(10)]
        self._lbl = MDLabel(text=day_name, halign="center", valign="middle",
                            font_style="Caption", bold=True,
                            theme_text_color="Custom")
        self.add_widget(self._lbl)
        self._apply_style()

    def on_release(self):
        self.is_selected = not self.is_selected
        self._apply_style()

    def _apply_style(self):
        app = MDApp.get_running_app()
        if app is None:
            return
        if self.is_selected:
            self.md_bg_color = app.theme_cls.primary_color
            self._lbl.text_color = (1, 1, 1, 1)
        else:
            dark = app.theme_cls.theme_style == 'Dark'
            self.md_bg_color = (0.18, 0.18, 0.18, 1) if dark else (0.88, 0.88, 0.88, 1)
            self._lbl.text_color = (0.7, 0.7, 0.7, 1) if dark else (0.3, 0.3, 0.3, 1)


# ── Экраны ────────────────────────────────────────────────────────────────────

class HomeScreen(MDScreen):
    pass


class ImportScreen(MDScreen):
    pass


class ShareScreen(MDScreen):
    pass


class AddLessonScreen(MDScreen):
    _day_buttons: list = []

    def on_pre_enter(self, *args):
        self._build_day_buttons()

    def _build_day_buttons(self):
        container = self.ids.days_container
        container.clear_widgets()
        self._day_buttons = []
        for i, name in enumerate(DAYS_SHORT):
            btn = DayToggleButton(day_index=i, day_name=name)
            container.add_widget(btn)
            self._day_buttons.append(btn)

    def get_selected_days(self) -> list:
        return [b.day_index for b in self._day_buttons if b.is_selected]

    def set_selected_days(self, days: list):
        for b in self._day_buttons:
            b.is_selected = b.day_index in days
            b._apply_style()


class SettingsScreen(MDScreen):

    def on_pre_enter(self, *args):
        app = MDApp.get_running_app()
        s = app.settings
        self.ids.auto_sw.active = s.get('automation_enabled', True)
        self.ids.theme_sw.active = s.get('dark_theme', True)
        self.ids.dnd_sw.active = s.get('dnd_during_lesson', True)
        self.ids.wifi_sw.active = s.get('warn_no_wifi', False)
        self.ids.lock_sw.active = s.get('lock_after_lesson', True)
        self.ids.cal_sw.active = s.get('calendar_sync', True)
        self.ids.buffer_field.text = str(s.get('wake_buffer_minutes', 1))
        self.ids.duration_field.text = str(s.get('lesson_duration_minutes', 45))
        app.refresh_status()


# ── Главный класс приложения ──────────────────────────────────────────────────

class TeamsSchedulerApp(MDApp):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.lessons: dict = {}
        self.settings: dict = dict(DEFAULT_SETTINGS)
        self._data_file: str = ''
        self._dialog = None
        self._editing_id: str | None = None
        self._pending_import: list = []
        self._sim_state: dict = {'joined': {}}
        self._shared_url: str | None = None

    # ── Инициализация ──────────────────────────────────────────────────────

    def build(self):
        self.theme_cls.primary_palette = "DeepPurple"
        self.theme_cls.accent_palette  = "Purple"
        self.theme_cls.theme_style     = "Dark"
        Window.softinput_mode = "below_target"
        return Builder.load_string(KV)

    def on_start(self):
        self._data_file = os.path.join(core.data_dir(), 'lessons.json')
        self._load()
        self._apply_theme()
        self._refresh_home()
        self._update_date(0)

        Clock.schedule_interval(self._update_date, 60)
        Clock.schedule_interval(self._check_schedule, 20)

        if platform == 'android':
            self._request_notifications()
            self._start_service()
            self._hook_share_intent()

    # ── Хранение данных ────────────────────────────────────────────────────

    def _load(self):
        if not os.path.exists(self._data_file):
            return
        try:
            with open(self._data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.lessons = data.get('lessons', {})
            self.settings.update(data.get('settings', {}))
        except Exception as e:
            log.error(f"[App] Ошибка загрузки: {e}")

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self._data_file), exist_ok=True)
            with open(self._data_file, 'w', encoding='utf-8') as f:
                json.dump({'lessons': self.lessons, 'settings': self.settings},
                          f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.error(f"[App] Ошибка сохранения: {e}")

    # ── Тема ───────────────────────────────────────────────────────────────

    def _apply_theme(self):
        self.theme_cls.theme_style = 'Dark' if self.settings.get('dark_theme', True) else 'Light'

    def toggle_theme(self, dark: bool):
        self.settings['dark_theme'] = bool(dark)
        self._save()
        self._apply_theme()
        self._refresh_home()

    # ── Обновление главного экрана ─────────────────────────────────────────

    def _refresh_home(self):
        home = self.root.get_screen('home')
        lst = home.ids.lessons_list
        lst.clear_widgets()

        enabled = self.settings.get('automation_enabled', True)
        home.ids.status_emoji.text = "✅" if enabled else "⏸"
        home.ids.status_label.text = ("Автоматизация включена"
                                      if enabled else "Автоматизация отключена")

        h = core.health()
        if h['a11y'] is None:
            home.ids.health_label.text = "Режим симуляции (ПК)"
        else:
            mark = lambda v: '✅' if v else '❌'
            home.ids.health_label.text = (f"Спец. возможности {mark(h['a11y'])} · "
                                          f"Календарь {mark(h['calendar'])} · "
                                          f"Не беспокоить {mark(h['dnd'])}")

        sorted_lessons = sorted(self.lessons.values(), key=lambda x: x.get('time', '00:00'))

        if not sorted_lessons:
            lst.add_widget(MDLabel(
                text="Нет уроков. Нажмите + чтобы добавить или 📥 чтобы импортировать.",
                halign="center", theme_text_color="Secondary",
                size_hint_y=None, height=dp(72)))
            return

        for lesson in sorted_lessons:
            lst.add_widget(self._build_lesson_card(lesson))

    def _build_lesson_card(self, lesson: dict):
        lid = lesson['id']
        now = datetime.now()
        enabled = lesson.get('enabled', True)

        card = MDCard(size_hint_y=None, height=dp(140), padding=dp(12),
                      elevation=2, radius=[dp(14)])
        row = MDBoxLayout(spacing=dp(8))

        left = MDBoxLayout(orientation='vertical', size_hint_x=None, width=dp(60))
        left.add_widget(MDLabel(text="🎓" if enabled else "💤", font_size="22sp",
                                halign="center", size_hint_y=None, height=dp(30)))
        left.add_widget(MDLabel(text=lesson.get('time', '--:--'), bold=True,
                                font_style="H6", halign="center",
                                size_hint_y=None, height=dp(32)))

        center = MDBoxLayout(orientation='vertical', spacing=dp(2))
        center.add_widget(self._clip(MDLabel(
            text=lesson.get('name', ''), bold=True, font_style="Subtitle1",
            theme_text_color="Primary" if enabled else "Hint",
            size_hint_y=None, height=dp(28))))
        days_text = self._days_text(lesson.get('days', []))
        center.add_widget(self._clip(MDLabel(
            text=days_text if enabled else days_text + " · выключен",
            font_style="Caption", theme_text_color="Secondary",
            size_hint_y=None, height=dp(20))))
        center.add_widget(MDLabel(
            text=self._next_occurrence(lesson, now),
            font_style="Caption", theme_text_color="Hint",
            size_hint_y=None, height=dp(20)))
        skipped = core.next_occurrence_skipped(lesson, now)
        center.add_widget(MDFlatButton(
            text="ВЕРНУТЬ УРОК" if skipped else "ПРОПУСТИТЬ БЛИЖАЙШИЙ",
            size_hint=(None, None), width=dp(200), height=dp(28),
            font_size="12sp",
            on_release=lambda _, l=lid: self.toggle_skip_next(l)))

        right = MDBoxLayout(orientation='vertical', size_hint_x=None, width=dp(56))
        sw = MDSwitch(active=enabled, size_hint=(None, None), size=(dp(46), dp(28)),
                      pos_hint={'center_x': .5})
        sw.bind(active=lambda _, v, l=lid: self.toggle_lesson(l, v))
        right.add_widget(sw)
        right.add_widget(MDIconButton(
            icon="pencil", theme_text_color="Secondary",
            size_hint=(None, None), size=(dp(40), dp(40)),
            on_release=lambda _, l=lid: self.edit_lesson(l)))
        right.add_widget(MDIconButton(
            icon="delete-outline", theme_text_color="Custom",
            text_color=(0.95, 0.35, 0.35, 1),
            size_hint=(None, None), size=(dp(40), dp(40)),
            on_release=lambda _, l=lid: self.confirm_delete(l)))

        row.add_widget(left)
        row.add_widget(center)
        row.add_widget(right)
        card.add_widget(row)
        return card

    @staticmethod
    def _days_text(days: list) -> str:
        if not days or len(days) == 7:
            return "Каждый день"
        return " ".join(DAYS_SHORT[d] for d in sorted(days))

    @staticmethod
    def _clip(lbl):
        lbl.shorten = True
        lbl.shorten_from = 'right'
        lbl.bind(width=lambda w, v: setattr(w, 'text_size', (v, None)))
        return lbl

    def _next_occurrence(self, lesson: dict, now=None) -> str:
        now = now or datetime.now()
        if not lesson.get('enabled', True):
            return "Урок выключен"
        dt = core.next_occurrence(lesson, now)
        if dt is None:
            return "Нет ближайших уроков"
        t = dt.strftime('%H:%M')
        if dt.date() == now.date():
            return f"Сегодня в {t}"
        if (dt.date() - now.date()).days == 1:
            return f"Завтра в {t}"
        return f"{DAYS_FULL[dt.weekday()]} в {t}"

    # ── Дата ───────────────────────────────────────────────────────────────

    def _update_date(self, _dt):
        now = datetime.now()
        text = (f"{DAYS_FULL[now.weekday()]}, "
                f"{now.day} {MONTHS_RU[now.month - 1]} {now.year}")
        try:
            self.root.get_screen('home').ids.date_label.text = text
        except Exception:
            pass

    # ── Расписание на ПК (симуляция; на Android расписание ведёт сервис) ─────

    def _check_schedule(self, _dt):
        if platform == 'android' or not self.settings.get('automation_enabled', True):
            return
        data = {'lessons': self.lessons}
        for s in core.due_sessions(self.settings, data, self._sim_state):
            if core.mark_joined(self._sim_state, s):
                self._trigger_join(s)

    def _trigger_join(self, s: dict):
        log.info("симуляция входа: %s в %s", s['name'], s.get('start_ms'))
        try:
            from automation import TeamsAutomation
            auto = TeamsAutomation()
            auto.wake_and_unlock()
            auto.join_meeting(s['url'], mute_mic=s['mute_mic'], mute_cam=s['mute_cam'])
        except ImportError:
            Snackbar(text=f"⏰ Время урока: {s['name']}!").open()
        except Exception as e:
            log.error("автоматизация: %s", e)
            Snackbar(text=f"⏰ {s['name']} — войди вручную!").open()

    # ── Навигация ──────────────────────────────────────────────────────────

    def go_screen(self, name: str):
        if name == 'add_lesson':
            self._editing_id = None
            self._reset_form()
            self.root.get_screen('add_lesson').ids.add_toolbar.title = 'Новый урок'
        self.root.current = name

    # ── Форма добавления / редактирования ─────────────────────────────────

    def _reset_form(self):
        s = self.root.get_screen('add_lesson')
        s.ids.name_field.text = ''
        s.ids.url_field.text = ''
        s.ids.hour_field.text = ''
        s.ids.minute_field.text = ''
        s.ids.mute_mic_sw.active = True
        s.ids.mute_cam_sw.active = True

    def edit_lesson(self, lesson_id: str):
        lesson = self.lessons.get(lesson_id)
        if not lesson:
            return
        self._editing_id = lesson_id

        s = self.root.get_screen('add_lesson')
        s.ids.add_toolbar.title = 'Редактировать урок'
        if not getattr(s, '_day_buttons', []):
            s._build_day_buttons()

        s.ids.name_field.text = lesson.get('name', '')
        s.ids.url_field.text = lesson.get('meeting_url', '')
        try:
            h, m = lesson.get('time', '09:00').split(':')
            s.ids.hour_field.text = h
            s.ids.minute_field.text = m
        except ValueError:
            pass
        s.ids.mute_mic_sw.active = lesson.get('mute_mic', True)
        s.ids.mute_cam_sw.active = lesson.get('mute_camera', True)
        s.set_selected_days(lesson.get('days', []))
        self.root.current = 'add_lesson'

    def _collect_lesson(self):
        """Читает форму. Возвращает урок или None (и показывает подсказку)."""
        s = self.root.get_screen('add_lesson')
        name = s.ids.name_field.text.strip()
        url = s.ids.url_field.text.strip()
        h_str = s.ids.hour_field.text.strip()
        m_str = s.ids.minute_field.text.strip()

        if not name:
            Snackbar(text="Введите название урока").open()
            return None
        if not h_str or not m_str:
            Snackbar(text="Введите время урока").open()
            return None
        try:
            hh, mm = int(h_str), int(m_str)
            assert 0 <= hh <= 23 and 0 <= mm <= 59
        except (ValueError, AssertionError):
            Snackbar(text="Неверное время. Час: 0–23, минуты: 0–59").open()
            return None

        days = s.get_selected_days() or list(range(7))
        lesson_id = self._editing_id or str(uuid.uuid4())
        previous = self.lessons.get(lesson_id, {})
        return {
            'id':          lesson_id,
            'name':        name,
            'meeting_url': url,
            'time':        f"{hh:02d}:{mm:02d}",
            'days':        days,
            'mute_mic':    s.ids.mute_mic_sw.active,
            'mute_camera': s.ids.mute_cam_sw.active,
            'enabled':     previous.get('enabled', True),
            'duration_minutes': previous.get('duration_minutes'),
            'skip_dates': previous.get('skip_dates', []),
            'created_at':  previous.get('created_at', datetime.now().isoformat()),
        }

    def save_lesson(self):
        lesson = self._collect_lesson()
        if lesson is None:
            return

        dup = core.find_duplicate(self.lessons, lesson)
        if dup:
            Snackbar(text=f"Такой урок уже есть: «{dup['name']}» в {dup['time']}").open()
            return

        default_len = int(self.settings.get('lesson_duration_minutes', 45))
        overlaps = core.find_overlaps(self.lessons, lesson, default_len)
        if overlaps:
            self._show_overlap_dialog(lesson, overlaps)
            return
        self._store_lesson(lesson)

    def _show_overlap_dialog(self, lesson: dict, names: list):
        self._dialog = MDDialog(
            title="Пересечение по времени",
            text=f"«{lesson['name']}» пересекается с: {', '.join(names)}. Всё равно сохранить?",
            buttons=[
                MDFlatButton(text="ИЗМЕНИТЬ",
                             on_release=lambda _: self._dialog.dismiss()),
                MDRaisedButton(text="СОХРАНИТЬ",
                               on_release=lambda _: self._confirm_overlap(lesson)),
            ],
        )
        self._dialog.open()

    def _confirm_overlap(self, lesson: dict):
        self._dialog.dismiss()
        self._store_lesson(lesson)

    def _store_lesson(self, lesson: dict):
        verb = "обновлён" if self._editing_id else "добавлен"
        self.lessons[lesson['id']] = lesson
        self._save()
        self._refresh_home()
        Snackbar(text=f"Урок «{lesson['name']}» {verb}").open()
        self._editing_id = None
        self.root.current = 'home'

    # ── Импорт из текста ───────────────────────────────────────────────────

    def parse_import(self):
        text = self.root.get_screen('import').ids.import_field.text
        if not text.strip():
            Snackbar(text="Вставь расписание в поле").open()
            return
        if text.lstrip().startswith('{'):
            lessons, errors = core.parse_lessons_json(text)
        else:
            lessons, errors = core.parse_schedule_text(text)
        default_len = int(self.settings.get('lesson_duration_minutes', 45))

        new, skipped, warnings = [], [], []
        pool = dict(self.lessons)
        for l in lessons:
            dup = core.find_duplicate(pool, l)
            if dup:
                skipped.append(f"«{l['name']}» уже есть")
                continue
            ov = core.find_overlaps(pool, l, default_len)
            if ov:
                warnings.append(f"«{l['name']}» {l['time']} пересекается с: {', '.join(ov)}")
            pool[l['id']] = l
            new.append(l)

        if not new:
            details = errors + skipped
            Snackbar(text="Нечего добавлять. " + ("; ".join(details[:2]) or "")).open()
            return

        self._pending_import = new
        lines = [f"• {l['name']} — {self._days_text(l['days'])}, {l['time']}" for l in new]
        body = "\n".join(lines[:12]) + ("\n…" if len(lines) > 12 else "")
        if skipped:
            body += "\n\nПропущено (дубли): " + "; ".join(skipped)
        if warnings:
            body += "\n\n⚠️ " + "\n⚠️ ".join(warnings)
        if errors:
            body += "\n\nНе распознано: " + "; ".join(errors)

        self._dialog = MDDialog(
            title=f"Найдено уроков: {len(new)}",
            text=body,
            buttons=[
                MDFlatButton(text="ОТМЕНА", on_release=lambda _: self._dialog.dismiss()),
                MDRaisedButton(text="ДОБАВИТЬ", on_release=lambda _: self.confirm_import()),
            ],
        )
        self._dialog.open()

    def confirm_import(self):
        self._dialog.dismiss()
        for l in self._pending_import:
            self.lessons[l['id']] = l
        count = len(self._pending_import)
        self._pending_import = []
        self._save()
        self._refresh_home()
        self.root.get_screen('import').ids.import_field.text = ''
        Snackbar(text=f"Добавлено уроков: {count}").open()
        self.root.current = 'home'

    # ── Удаление ───────────────────────────────────────────────────────────

    def confirm_delete(self, lesson_id: str):
        lesson = self.lessons.get(lesson_id)
        if not lesson:
            return
        self._dialog = MDDialog(
            title="Удалить урок?",
            text=f"«{lesson['name']}» будет удалён навсегда.",
            buttons=[
                MDFlatButton(text="ОТМЕНА",
                             on_release=lambda _: self._dialog.dismiss()),
                MDRaisedButton(text="УДАЛИТЬ",
                               md_bg_color=(0.9, 0.3, 0.3, 1),
                               on_release=lambda _, lid=lesson_id: self._do_delete(lid)),
            ],
        )
        self._dialog.open()

    def _do_delete(self, lesson_id: str):
        self._dialog.dismiss()
        name = self.lessons.pop(lesson_id, {}).get('name', '')
        self._save()
        self._refresh_home()
        Snackbar(text=f"Урок «{name}» удалён").open()

    # ── Ссылка из Teams через «Поделиться» ─────────────────────────────────

    def _hook_share_intent(self):
        """Ловит текст, которым поделились из Teams: и при запуске, и когда приложение уже открыто."""
        try:
            from jnius import autoclass
            from android import activity as android_activity
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            android_activity.bind(on_new_intent=self._on_new_intent)
            self._consume_share(PythonActivity.mActivity)
        except Exception as e:
            log.warning("share hook: %s", e)

    def _on_new_intent(self, intent):
        from kivy.clock import Clock as _Clock
        _Clock.schedule_once(lambda _dt: self._consume_share_intent(intent), 0)

    def _consume_share(self, activity):
        self._consume_share_intent(activity.getIntent(), activity)

    def _consume_share_intent(self, intent, activity=None):
        text = core.share_text_from_intent(intent)
        if not text:
            return
        if activity is None:
            try:
                from jnius import autoclass
                activity = autoclass('org.kivy.android.PythonActivity').mActivity
            except Exception:
                activity = None
        if activity is not None:
            core.clear_share_intent(activity)
        self.handle_shared_text(text)

    def handle_shared_text(self, text: str):
        url = core.extract_teams_url(text)
        if not url:
            Snackbar(text="В тексте нет ссылки Teams").open()
            return
        self._shared_url = url
        if not self.lessons:
            Snackbar(text="Уроков пока нет — создам новый с этой ссылкой").open()
            self.share_new_lesson()
            return
        scr = self.root.get_screen('share')
        scr.ids.share_url_label.text = "Ссылка: " + (url if len(url) <= 70 else url[:67] + "…")
        scr.ids.share_all_sw.active = False
        box = scr.ids.share_list
        box.clear_widgets()
        for l in sorted(self.lessons.values(), key=lambda x: (norm_name_for_ui(x.get('name')), x.get('time', ''))):
            mark = "  (уже есть ссылка)" if l.get('meeting_url') else ""
            box.add_widget(MDRaisedButton(
                text=f"{l.get('name', '')} · {self._days_text(l.get('days', []))} {l.get('time', '')}{mark}",
                size_hint=(1, None), height=dp(48),
                on_release=lambda _, lid=l['id']: self.choose_share(lid)))
        self.root.current = 'share'

    def choose_share(self, lesson_id: str):
        all_same = self.root.get_screen('share').ids.share_all_sw.active
        count = core.apply_share(self.lessons, self._shared_url, lesson_id, all_same)
        self._shared_url = None
        self._save()
        self._refresh_home()
        Snackbar(text=f"Ссылка сохранена в уроков: {count}").open()
        self.root.current = 'home'

    def share_new_lesson(self):
        url = self._shared_url
        self._shared_url = None
        self._editing_id = None
        self._reset_form()
        s = self.root.get_screen('add_lesson')
        s.ids.url_field.text = url or ''
        s.ids.add_toolbar.title = 'Новый урок'
        self.root.current = 'add_lesson'

    def cancel_share(self):
        self._shared_url = None
        self.root.current = 'home'

    # ── Экспорт и вкл/выкл уроков ──────────────────────────────────────────

    def export_lessons(self):
        from kivy.core.clipboard import Clipboard
        Clipboard.copy(core.export_lessons_json({'lessons': self.lessons}))
        Snackbar(text=f"Скопировано уроков: {len(self.lessons)}").open()

    def toggle_lesson(self, lesson_id: str, active: bool):
        lesson = self.lessons.get(lesson_id)
        if lesson and lesson.get('enabled', True) != bool(active):
            lesson['enabled'] = bool(active)
            self._save()
            self._refresh_home()

    def toggle_skip_next(self, lesson_id: str):
        lesson = self.lessons.get(lesson_id)
        if not lesson:
            return
        skipped = core.toggle_skip_next(lesson, datetime.now())
        self._save()
        self._refresh_home()
        Snackbar(text="Ближайший урок пропущен" if skipped else "Пропуск снят").open()

    # ── Настройки ──────────────────────────────────────────────────────────

    def toggle_automation(self, active: bool):
        self.settings['automation_enabled'] = active
        self._save()
        self._refresh_home()

    def set_flag(self, key: str, active: bool):
        self.settings[key] = bool(active)
        self._save()

    def update_buffer(self, text: str):
        try:
            self.settings['wake_buffer_minutes'] = core.clamp_buffer(int(text))
            self._save()
        except ValueError:
            pass

    def update_duration(self, text: str):
        try:
            self.settings['lesson_duration_minutes'] = max(1, int(text))
            self._save()
        except ValueError:
            pass

    def copy_dump(self):
        from kivy.core.clipboard import Clipboard
        try:
            with open(os.path.join(core.data_dir(), 'a11y_dump.txt'), encoding='utf-8') as f:
                Clipboard.copy(f.read())
            Snackbar(text="Дамп скопирован в буфер обмена").open()
        except Exception:
            Snackbar(text="Дампа пока нет: он создаётся во время урока в Teams").open()

    # ── Календарь и статусы ────────────────────────────────────────────────

    def req_calendar(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        core.request_calendar_permission(
            lambda perms, res: Clock.schedule_once(
                lambda _: (self.refresh_status(), self.sync_calendar_now()), 0))

    def sync_calendar_now(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        if not core.has_calendar_permission():
            Snackbar(text="Сначала дай доступ к календарю").open()
            return
        events = core.sync_calendar(force=True)
        self.refresh_status()
        Snackbar(text=f"Найдено событий Teams: {len(events)}").open()

    def refresh_status(self):
        if platform != 'android':
            return
        try:
            s = self.root.get_screen('settings')
            ev = len(core.load_state().get('events', []))
            ok = core.has_calendar_permission()
            s.ids.cal_status.text = (f"Событий со ссылкой Teams на 7 дней: {ev}"
                                     if ok else "Нет доступа к календарю")
            on = core.accessibility_enabled()
            s.ids.a11y_label.text = ("Спец. возможности ✅ включены" if on
                                     else "Спец. возможности ❌ выключены")
            s.ids.dnd_label.text = ("Не беспокоить ✅ доступ дан" if core.dnd_access()
                                    else "Не беспокоить ❌ доступ не дан")
        except Exception as e:
            log.warning(f"refresh_status: {e}")

    # ── Разрешения Android ─────────────────────────────────────────────────

    def _request_notifications(self):
        try:
            from android.permissions import request_permissions
            request_permissions(['android.permission.POST_NOTIFICATIONS'])
        except Exception as e:
            log.warning(f"уведомления: {e}")

    def req_overlay(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        from automation import TeamsAutomation
        TeamsAutomation.request_overlay()

    def req_battery(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        from automation import TeamsAutomation
        TeamsAutomation.request_battery_opt()

    def open_accessibility(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        from automation import TeamsAutomation
        TeamsAutomation.open_accessibility()

    def open_dnd_access(self):
        if platform != 'android':
            Snackbar(text="Только для Android").open()
            return
        from automation import TeamsAutomation
        TeamsAutomation.request_dnd_access()

    # ── Фоновый сервис Android ─────────────────────────────────────────────

    def _start_service(self):
        try:
            from android import AndroidService
            svc = AndroidService('Teams Scheduler', 'Мониторинг уроков...')
            svc.start('started')
            log.info("[App] Сервис запущен")
        except Exception as e:
            log.error(f"Не удалось запустить сервис: {e}")


# ── Точка входа ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    TeamsSchedulerApp().run()
