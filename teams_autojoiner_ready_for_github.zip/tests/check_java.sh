#!/usr/bin/env bash
# Проверка Java-кода без Android SDK: компилируем заглушки Android и наш код.
# Нужен JDK (javac или модуль jdk.compiler). Заглушки повторяют сигнатуры
# Android API, но это НЕ android.jar: ловятся синтаксис, типы, проверяемые
# исключения и ссылки внутри проекта.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
if command -v javac >/dev/null 2>&1; then
  JC="javac"
else
  JC="java -m jdk.compiler/com.sun.tools.javac.Main"
fi
$JC -d "$OUT/stubs" $(find "$ROOT/tests/java_stubs" -name "*.java") 
$JC -Xlint:all -cp "$OUT/stubs" -d "$OUT/app" $(find "$ROOT/java" -name "*.java")
echo "Java: компиляция прошла (предупреждения, если есть, выведены выше)"
