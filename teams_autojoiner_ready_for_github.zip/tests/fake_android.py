"""
Стенд для проверки Android-логики на ПК.
Подменяет модуль jnius и объекты Android именами методов и констант,
которые реально использует код. Проверяет ЛОГИКУ и ВЫЗОВЫ, а не поведение
настоящей системы Android.
"""

import sys
import types
import os
import json
import tempfile


class FakeCursor:
    def __init__(self, rows):
        self.rows, self.i = list(rows), -1

    def moveToNext(self):
        self.i += 1
        return self.i < len(self.rows)

    def _v(self, idx):
        return self.rows[self.i][idx]

    def getString(self, idx):
        v = self._v(idx)
        return None if v is None else str(v)

    def getInt(self, idx):
        v = self._v(idx)
        return 0 if v is None else int(v)

    def getLong(self, idx):
        v = self._v(idx)
        return 0 if v is None else int(v)

    def close(self):
        pass


class FakeWorld:
    """Всё, что «видит» телефон в одном тесте."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.calendar_rows = []      # строки Instances (10 колонок)
        self.calendars = []          # (_id, name, displayName)
        self.net = 'wifi'            # wifi | cellular | no_internet | no_network
        self.dnd_granted = True
        self.dnd_filter = 1          # INTERRUPTION_FILTER_ALL
        self.notifications = []      # (title, text, sid, actions)
        self.broadcasts = 0
        self.launched = []           # вызовы TeamsAutomation.join_meeting
        self.dnd_calls = []
        self.accessibility_on = True


W = FakeWorld()


class FakeCaps:
    def __init__(self, net):
        self.net = net

    def hasCapability(self, cap):
        if cap == 12:       # NET_CAPABILITY_INTERNET
            return self.net in ('wifi', 'cellular', 'other')
        if cap == 16:       # NET_CAPABILITY_VALIDATED
            return self.net in ('wifi', 'cellular', 'other')
        return False

    def hasTransport(self, t):
        if t == 1:          # TRANSPORT_WIFI
            return self.net == 'wifi'
        if t == 0:          # TRANSPORT_CELLULAR
            return self.net == 'cellular'
        return False


class FakeCM:
    def getActiveNetwork(self):
        return None if W.net == 'no_network' else object()

    def getNetworkCapabilities(self, _):
        return FakeCaps(W.net)


class FakeNM:
    def isNotificationPolicyAccessGranted(self):
        return W.dnd_granted

    def getCurrentInterruptionFilter(self):
        return W.dnd_filter

    def setInterruptionFilter(self, f):
        W.dnd_filter = f
        W.dnd_calls.append(f)


class FakeResolver:
    def query(self, uri, proj, sel, args, order):
        return FakeCursor(W.calendars)


class FakeDir:
    def __init__(self, path):
        self.path = path

    def getAbsolutePath(self):
        return self.path


class FakeCtx:
    def __init__(self, path):
        self.path = path

    def getFilesDir(self):
        return FakeDir(self.path)

    def getSystemService(self, name):
        if name == 'connectivity':
            return FakeCM()
        if name == 'notification':
            return FakeNM()
        return None

    def getContentResolver(self):
        return FakeResolver()

    def getPackageName(self):
        return 'org.student.teams.teamsautojoiner'

    def sendBroadcast(self, intent):
        W.broadcasts += 1


class FakeNotifyHelper:
    @staticmethod
    def show(ctx, nid, title, text, sid, actions):
        W.notifications.append({'title': title, 'text': text, 'sid': sid, 'actions': actions})


class FakeIntent:
    def __init__(self, action=None):
        self.action = action

    def setClassName(self, pkg, cls):
        self.cls = cls


class FakeSecure:
    ENABLED_ACCESSIBILITY_SERVICES = 'enabled_accessibility_services'

    @staticmethod
    def getString(resolver, key):
        return 'org.student.teams.teamsautojoiner/TeamsAccessibilityService' if W.accessibility_on else ''


class FakeInstances:
    @staticmethod
    def query(resolver, proj, b, e):
        return FakeCursor(W.calendar_rows)


class FakeCalendars:
    CONTENT_URI = 'content://calendars'


class FakeTeamsAutomation:
    def wake_and_unlock(self):
        pass

    def join_meeting(self, url, mute_mic=True, mute_cam=True):
        W.launched.append({'url': url, 'mic': mute_mic, 'cam': mute_cam})


CLASSES = {
    'org.kivy.android.PythonService': None,   # особая обработка ниже
    'android.net.NetworkCapabilities': types.SimpleNamespace(
        NET_CAPABILITY_INTERNET=12, NET_CAPABILITY_VALIDATED=16,
        TRANSPORT_WIFI=1, TRANSPORT_CELLULAR=0),
    'android.content.Context': types.SimpleNamespace(
        CONNECTIVITY_SERVICE='connectivity', NOTIFICATION_SERVICE='notification',
        ALARM_SERVICE='alarm'),
    'android.app.NotificationManager': types.SimpleNamespace(
        INTERRUPTION_FILTER_ALL=1, INTERRUPTION_FILTER_ALARMS=4),
    'android.provider.CalendarContract$Instances': FakeInstances,
    'android.provider.CalendarContract$Calendars': FakeCalendars,
    'org.student.teams.teamsautojoiner.NotifyHelper': FakeNotifyHelper,
    'android.appwidget.AppWidgetManager': types.SimpleNamespace(
        ACTION_APPWIDGET_UPDATE='appwidget_update'),
    'android.content.Intent': FakeIntent,
    'android.provider.Settings$Secure': FakeSecure,
}


def _autoclass(name):
    if name == 'org.kivy.android.PythonService':
        return types.SimpleNamespace(mService=CURRENT_CTX)
    if name in CLASSES:
        return CLASSES[name]
    raise RuntimeError(f"стенд не знает класс {name}")


CURRENT_CTX = None


def install(home_dir):
    """Подменяет jnius и HOME, чтобы файлы состояния лежали во временной папке."""
    global CURRENT_CTX
    os.environ['HOME'] = home_dir
    CURRENT_CTX = FakeCtx(home_dir)
    jnius = types.ModuleType('jnius')
    jnius.autoclass = _autoclass
    sys.modules['jnius'] = jnius
    auto = types.ModuleType('automation')
    auto.TeamsAutomation = FakeTeamsAutomation
    sys.modules['automation'] = auto
    return CURRENT_CTX
