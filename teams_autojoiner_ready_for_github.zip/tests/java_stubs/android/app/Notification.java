package android.app;
import android.content.Context; import android.app.PendingIntent;
public class Notification {
  public static class Style {}
  public static class BigTextStyle extends Style { public BigTextStyle bigText(CharSequence t) { return this; } }
  public static final String CATEGORY_REMINDER = "reminder";
  public static class Builder {
    public Builder(Context c) {}
    public Builder(Context c, String channelId) {}
    public Builder setSmallIcon(int icon) { return this; }
    public Builder setContentTitle(CharSequence t) { return this; }
    public Builder setContentText(CharSequence t) { return this; }
    public Builder setStyle(Style s) { return this; }
    public Builder setAutoCancel(boolean b) { return this; }
    public Builder addAction(int icon, CharSequence title, PendingIntent pi) { return this; }
    public Notification build() { return new Notification(); }
  }
}