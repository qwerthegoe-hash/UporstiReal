package android.app;
import android.content.Context; import android.content.Intent;
public class PendingIntent {
  public static final int FLAG_UPDATE_CURRENT = 1 << 27;
  public static final int FLAG_IMMUTABLE = 1 << 26;
  public static PendingIntent getBroadcast(Context c, int r, Intent i, int f) { return null; }
  public static PendingIntent getActivity(Context c, int r, Intent i, int f) { return null; }
}