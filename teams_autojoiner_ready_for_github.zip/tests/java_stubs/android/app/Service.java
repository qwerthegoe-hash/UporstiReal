package android.app;
public class Service extends android.content.ContextWrapperStub {}