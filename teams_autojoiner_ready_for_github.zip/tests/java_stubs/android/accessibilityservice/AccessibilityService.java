package android.accessibilityservice;
import android.content.Context; import android.view.accessibility.*; import android.os.Handler;
public abstract class AccessibilityService extends Context {
  public static final int GLOBAL_ACTION_LOCK_SCREEN = 8;
  protected void onServiceConnected() {}
  public void onAccessibilityEvent(AccessibilityEvent e) {}
  public void onInterrupt() {}
  public void onDestroy() {}
  public AccessibilityNodeInfo getRootInActiveWindow() { return null; }
  public boolean performGlobalAction(int action) { return true; }
  public android.content.res.Resources getResources() { return null; }
  public boolean dispatchGesture(GestureDescription g, GestureResultCallback cb, Handler h) { return true; }
  public static abstract class GestureResultCallback {}
}