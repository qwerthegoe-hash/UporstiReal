package android.content;
public class ContextWrapperStub extends Context {}