package android.content.pm;
public class PackageManager { public android.content.Intent getLaunchIntentForPackage(String p) { return null; } }