package android.content;
public class Context {
  public static final String NOTIFICATION_SERVICE = "notification";
  public static final String CONNECTIVITY_SERVICE = "connectivity";
  public static final String ALARM_SERVICE = "alarm";
  public static final String AUDIO_SERVICE = "audio";
  public Object getSystemService(String name) { return null; }
  public java.io.File getFilesDir() { return null; }
  public android.content.ContentResolver getContentResolver() { return null; }
  public android.content.pm.PackageManager getPackageManager() { return null; }
  public String getPackageName() { return null; }
  public void sendBroadcast(Intent i) {}
  public void startActivity(Intent i) {}
}