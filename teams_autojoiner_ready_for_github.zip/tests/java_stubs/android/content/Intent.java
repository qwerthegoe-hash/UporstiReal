package android.content;
public class Intent {
  public static final String ACTION_BOOT_COMPLETED = "android.intent.action.BOOT_COMPLETED";
  public static final String ACTION_MY_PACKAGE_REPLACED = "android.intent.action.MY_PACKAGE_REPLACED";
  public static final String ACTION_VIEW = "android.intent.action.VIEW";
  public static final int FLAG_ACTIVITY_NEW_TASK = 0x10000000;
  public static final int FLAG_ACTIVITY_CLEAR_TOP = 0x04000000;
  public Intent() {}
  public Intent(String action) {}
  public Intent(Context c, Class<?> cls) {}
  public Intent setAction(String a) { return this; }
  public String getAction() { return null; }
  public Intent putExtra(String k, String v) { return this; }
  public Intent putExtra(String k, int v) { return this; }
  public String getStringExtra(String k) { return null; }
  public int getIntExtra(String k, int d) { return d; }
  public void addFlags(int f) {}
  public void setClassName(String pkg, String cls) {}
  public void setPackage(String p) {}
}