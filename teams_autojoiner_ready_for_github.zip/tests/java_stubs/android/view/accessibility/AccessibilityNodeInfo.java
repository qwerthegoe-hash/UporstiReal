package android.view.accessibility;
public class AccessibilityNodeInfo {
  public static final int ACTION_CLICK = 16;
  public CharSequence getText() { return null; }
  public CharSequence getContentDescription() { return null; }
  public CharSequence getPackageName() { return null; }
  public CharSequence getClassName() { return null; }
  public boolean isVisibleToUser() { return true; }
  public boolean isClickable() { return true; }
  public boolean isCheckable() { return false; }
  public boolean isChecked() { return false; }
  public AccessibilityNodeInfo getParent() { return null; }
  public int getChildCount() { return 0; }
  public AccessibilityNodeInfo getChild(int i) { return null; }
  public boolean performAction(int a) { return true; }
}