package android.appwidget;
import android.content.*;
public class AppWidgetProvider extends BroadcastReceiver {
  public void onUpdate(Context c, AppWidgetManager m, int[] ids) {}
  @Override public void onReceive(Context c, Intent i) {}
}