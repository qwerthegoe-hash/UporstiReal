package android.appwidget;
public class AppWidgetManager {
  public static final String ACTION_APPWIDGET_UPDATE = "android.appwidget.action.APPWIDGET_UPDATE";
  public void updateAppWidget(int id, android.widget.RemoteViews v) {}
}