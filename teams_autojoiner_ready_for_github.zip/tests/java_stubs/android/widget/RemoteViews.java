package android.widget;
import android.app.PendingIntent;
public class RemoteViews {
  public RemoteViews(String pkg, int layoutId) {}
  public void setTextViewText(int id, CharSequence t) {}
  public void setOnClickPendingIntent(int id, PendingIntent pi) {}
}