package org.json;
public class JSONObject {
  public JSONObject() {}
  public JSONObject(String s) throws JSONException {}
  public JSONObject put(String k, Object v) throws JSONException { return this; }
  public JSONObject put(String k, long v) throws JSONException { return this; }
  public JSONObject put(String k, boolean v) throws JSONException { return this; }
  public String optString(String k, String d) { return d; }
  public String optString(String k) { return ""; }
  public long optLong(String k, long d) { return d; }
  public long optLong(String k) { return 0L; }
  public boolean optBoolean(String k, boolean d) { return d; }
  public boolean has(String k) { return false; }
}