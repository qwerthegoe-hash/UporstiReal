package org.student.teams.teamsautojoiner;
public final class R {
  public static final class layout { public static final int widget_lesson = 1; }
  public static final class id { public static final int w_root=1, w_title=2, w_when=3, w_status=4; }
}