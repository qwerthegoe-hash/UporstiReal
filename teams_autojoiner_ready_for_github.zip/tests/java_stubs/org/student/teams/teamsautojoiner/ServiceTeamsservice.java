package org.student.teams.teamsautojoiner;
public class ServiceTeamsservice { public static void start(android.content.Context c, String arg) {} }