"""
Тесты чистой логики core.py. Запуск из корня проекта:
    python -m unittest discover -s tests -v
На ПК Android-вызовы не выполняются, поэтому тесты проверяют только расчёты.
"""

import os
import sys
import json
import tempfile
import unittest
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import core  # noqa: E402

MON_0858 = datetime(2026, 11, 9, 8, 58, 0)     # понедельник


def ms(dt):
    return int(dt.timestamp() * 1000)


def lesson(name, time, days=None, **extra):
    d = {'id': name, 'name': name, 'time': time,
         'days': days if days is not None else list(range(7)),
         'meeting_url': '', 'enabled': True, 'mute_mic': True, 'mute_camera': True}
    d.update(extra)
    return d


class ParseTextTests(unittest.TestCase):

    def test_days_time_range_and_url(self):
        text = "Математика Пн Ср 09:00-10:30 https://teams.microsoft.com/l/meetup-join/abc"
        lessons, errors = core.parse_schedule_text(text)
        self.assertEqual(errors, [])
        l = lessons[0]
        self.assertEqual(l['name'], 'Математика')
        self.assertEqual(l['days'], [0, 2])
        self.assertEqual(l['time'], '09:00')
        self.assertEqual(l['duration_minutes'], 90)
        self.assertTrue(l['meeting_url'].startswith('https://teams.microsoft.com/'))

    def test_day_range_and_no_days(self):
        lessons, _ = core.parse_schedule_text("Пн-Пт 14:00 Английский\nХимия 11:00")
        self.assertEqual(lessons[0]['days'], [0, 1, 2, 3, 4])
        self.assertEqual(lessons[1]['days'], list(range(7)))

    def test_bullet_and_dot_time(self):
        lessons, _ = core.parse_schedule_text("- История Чт 9.30")
        self.assertEqual(lessons[0]['name'], 'История')
        self.assertEqual(lessons[0]['time'], '09:30')

    def test_errors_reported(self):
        lessons, errors = core.parse_schedule_text("Без времени Пт\nПусто 25:99\n")
        self.assertEqual(lessons, [])
        self.assertEqual(len(errors), 2)


class JsonTests(unittest.TestCase):

    def test_export_then_import_roundtrip(self):
        data = {'lessons': {'a': lesson('Физика', '10:00', [0, 1], skip_dates=['2026-11-09'])}}
        text = core.export_lessons_json(data)
        lessons, errors = core.parse_lessons_json(text)
        self.assertEqual(errors, [])
        self.assertEqual(lessons[0]['name'], 'Физика')
        self.assertEqual(lessons[0]['skip_dates'], ['2026-11-09'])
        self.assertNotEqual(lessons[0]['id'], 'a')          # id создаётся заново

    def test_invalid_json_and_bad_items(self):
        self.assertEqual(core.parse_lessons_json('не json')[1], ['не JSON'])
        lessons, errors = core.parse_lessons_json(json.dumps(
            {'lessons': [{'name': 'Ок', 'time': '08:00'}, {'name': 'Плохо', 'time': '99:00'},
                         {'time': '08:00'}]}))
        self.assertEqual([l['name'] for l in lessons], ['Ок'])
        self.assertEqual(len(errors), 2)


class OverlapAndDuplicateTests(unittest.TestCase):

    def test_overlap_only_on_shared_days(self):
        lessons = {'m': lesson('Математика', '09:00', [0])}
        cand = lesson('Тест', '09:30', [0])
        self.assertEqual(core.find_overlaps(lessons, cand, 45), ['Математика'])
        cand_tue = lesson('Тест', '09:30', [1])
        self.assertEqual(core.find_overlaps(lessons, cand_tue, 45), [])

    def test_no_overlap_when_adjacent(self):
        lessons = {'m': lesson('Математика', '09:00', [0])}     # до 09:45
        cand = lesson('Тест', '09:45', [0])
        self.assertEqual(core.find_overlaps(lessons, cand, 45), [])

    def test_duplicate_ignores_case_and_yo(self):
        lessons = {'x': lesson('Ёлка', '09:00', [0, 2])}
        cand = lesson('елка ', '09:00', [2], id='new')
        self.assertIsNotNone(core.find_duplicate(lessons, cand))


class SessionTests(unittest.TestCase):

    def settings(self, buffer=1):
        return {'wake_buffer_minutes': buffer, 'lesson_duration_minutes': 45}

    def test_calendar_event_replaces_schedule_duplicate(self):
        start = MON_0858 + timedelta(minutes=3)
        data = {'lessons': {'L': lesson('Математика', '09:01', [0])}}
        state = {'events': [{'key': 'k', 'name': 'математика', 'url': 'u',
                             'begin': ms(start), 'end': ms(start) + 3600000}]}
        found = core.sessions_between(self.settings(), data, state, -300, 300, MON_0858)
        self.assertEqual([s['source'] for s in found], ['calendar'])

    def test_schedule_alone_is_used(self):
        data = {'lessons': {'L': lesson('Математика', '09:01', [0])}}
        found = core.sessions_between(self.settings(), data, {'events': []}, -300, 300, MON_0858)
        self.assertEqual([s['source'] for s in found], ['schedule'])

    def test_skip_date_removes_session_and_moves_next(self):
        l = lesson('Математика', '09:01', [0])
        l['skip_dates'] = ['2026-11-09']
        data = {'lessons': {'L': l}}
        self.assertEqual(core.sessions_between(self.settings(), data, {'events': []},
                                               -300, 300, MON_0858), [])
        nxt = core.next_occurrence(l, MON_0858)
        self.assertEqual(nxt.date().isoformat(), '2026-11-16')

    def test_toggle_skip_twice_restores(self):
        l = lesson('Математика', '09:01', [0])
        self.assertTrue(core.toggle_skip_next(l, MON_0858))
        self.assertTrue(core.next_occurrence_skipped(l, MON_0858))
        self.assertFalse(core.toggle_skip_next(l, MON_0858))
        self.assertEqual(l['skip_dates'], [])

    def test_disabled_lesson_ignored(self):
        l = lesson('Математика', '09:01', [0], enabled=False)
        found = core.sessions_between(self.settings(), {'lessons': {'L': l}},
                                      {'events': []}, -300, 300, MON_0858)
        self.assertEqual(found, [])

    def test_pre_notice_window(self):
        data = {'lessons': {'L': lesson('Математика', '09:03', [0])}}
        hits = core.sessions_between(self.settings(), data, {'events': []},
                                     core.buffer_seconds(self.settings()), 300, MON_0858)
        self.assertEqual(len(hits), 1)

    def test_already_handled(self):
        data = {'lessons': {'L': lesson('Математика', '09:01', [0])}}
        s = core.sessions_between(self.settings(), data, {'events': []}, -300, 300, MON_0858)[0]
        state = {'events': []}
        self.assertFalse(core.already_handled(state, s))
        self.assertTrue(core.mark_joined(state, s))
        self.assertTrue(core.already_handled(state, s))
        self.assertFalse(core.mark_joined(state, s))


class SettingsTests(unittest.TestCase):

    def test_buffer_clamped(self):
        self.assertEqual(core.clamp_buffer(0), 1)
        self.assertEqual(core.clamp_buffer(-5), 1)
        self.assertEqual(core.clamp_buffer(99), 15)
        self.assertEqual(core.clamp_buffer('x'), 1)
        self.assertEqual(core.clamp_buffer(3), 3)

    def test_network_problem_rules(self):
        self.assertEqual(core.net_problem({}, 'wifi'), '')
        self.assertEqual(core.net_problem({}, 'cellular'), '')
        self.assertEqual(core.net_problem({'warn_no_wifi': True}, 'cellular'),
                         core.NET_TEXT['cellular'])
        self.assertEqual(core.net_problem({}, 'no_internet'), core.NET_TEXT['no_internet'])
        self.assertEqual(core.net_problem({}, 'no_network'), core.NET_TEXT['no_network'])

    def test_norm_name(self):
        self.assertEqual(core.norm_name("  Математика!  (Ё) "), "математика е")


class ShareTests(unittest.TestCase):

    def test_url_extracted_from_teams_share_text(self):
        text = ("Присоединиться к собранию Microsoft Teams\n"
                "https://teams.microsoft.com/l/meetup-join/19%3ameeting_abc%40thread.v2/0?context=x.")
        self.assertEqual(core.extract_teams_url(text).split('?')[0],
                         "https://teams.microsoft.com/l/meetup-join/19%3ameeting_abc%40thread.v2/0")

    def test_text_without_teams_link(self):
        self.assertEqual(core.extract_teams_url("просто текст https://example.com"), '')

    def test_apply_share_to_one_lesson(self):
        lessons = {'a': lesson('Алгебра', '09:00', [0], id='a'),
                   'b': lesson('Алгебра', '11:00', [2], id='b')}
        self.assertEqual(core.apply_share(lessons, 'https://teams.microsoft.com/x', 'a'), 1)
        self.assertEqual(lessons['a']['meeting_url'], 'https://teams.microsoft.com/x')
        self.assertEqual(lessons['b']['meeting_url'], '')

    def test_apply_share_to_all_same_name(self):
        lessons = {'a': lesson('Алгебра', '09:00', [0], id='a'),
                   'b': lesson('алгебра ', '11:00', [2], id='b'),
                   'c': lesson('Физика', '10:00', [1], id='c')}
        self.assertEqual(core.apply_share(lessons, 'https://teams.microsoft.com/x', 'a', True), 2)
        self.assertEqual(lessons['b']['meeting_url'], 'https://teams.microsoft.com/x')
        self.assertEqual(lessons['c']['meeting_url'], '')

    def test_apply_share_unknown_lesson(self):
        self.assertEqual(core.apply_share({}, 'u', 'missing'), 0)

    def test_share_text_from_intent(self):
        class FakeIntent:
            def __init__(self, action, text):
                self._a, self._t = action, text
            def getAction(self):
                return self._a
            def getStringExtra(self, key):
                return self._t if key == core.SHARE_EXTRA_TEXT else None
        self.assertEqual(core.share_text_from_intent(FakeIntent(core.SHARE_ACTION, 'hi')), 'hi')
        self.assertIsNone(core.share_text_from_intent(FakeIntent('android.intent.action.MAIN', 'hi')))
        self.assertIsNone(core.share_text_from_intent(None))


class ActionFileTests(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.mkdtemp()
        self._home = os.environ.get('HOME')
        os.environ['HOME'] = self._tmp

    def tearDown(self):
        if self._home is not None:
            os.environ['HOME'] = self._home

    def _write(self, payload):
        path = os.path.join(core.data_dir(), 'action.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f)

    def test_fresh_action_accepted_and_removed(self):
        now = 1_700_000_000_000
        self._write({'action': 'join', 'id': 'x', 'ts': now - 1000})
        act = core.pop_action(now_ms=now)
        self.assertEqual(act['action'], 'join')
        self.assertIsNone(core.pop_action(now_ms=now))

    def test_stale_action_rejected(self):
        now = 1_700_000_000_000
        self._write({'action': 'join', 'id': 'x', 'ts': now - 10 * 60000})
        self.assertIsNone(core.pop_action(now_ms=now))

    def test_action_without_timestamp_rejected(self):
        self._write({'action': 'skip', 'id': 'x'})
        self.assertIsNone(core.pop_action(now_ms=1_700_000_000_000))


if __name__ == '__main__':
    unittest.main()
