"""
Сценарии фонового сервиса на стенде (tests/fake_android.py).
Проверяют, что приложение делает то, что обещано в описании:
сеть (Wi-Fi, мобильная, без интернета), уведомление за 5 минут, вход один раз,
кнопки, «Не беспокоить», блокировку, виджет и фильтры календаря.

Запуск: python -m unittest discover -s tests -v
"""

import os
import sys
import json
import logging
import tempfile
import importlib.util
import unittest
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, 'tests'))

import fake_android as fa   # noqa: E402
import core                 # noqa: E402

logging.getLogger('tja').setLevel(logging.ERROR)

_svc_spec = importlib.util.spec_from_file_location(
    'svc_main', os.path.join(ROOT, 'service', 'main.py'))
svc = importlib.util.module_from_spec(_svc_spec)
_svc_spec.loader.exec_module(svc)

TEAMS = 'https://teams.microsoft.com/l/meetup-join/abc'


def ms_in(seconds):
    return int((datetime.now() + timedelta(seconds=seconds)).timestamp() * 1000)


class FlowBase(unittest.TestCase):

    def setUp(self):
        self.home = tempfile.mkdtemp()
        self.ctx = fa.install(self.home)
        fa.W.reset()
        core._last_widget = None
        self._orig_perm = core.has_calendar_permission
        core.has_calendar_permission = lambda: True
        self.settings = {'automation_enabled': True, 'wake_buffer_minutes': 1,
                         'lesson_duration_minutes': 45, 'calendar_sync': True,
                         'dnd_during_lesson': True, 'lock_after_lesson': True,
                         'warn_no_wifi': False}
        self.write_lessons({})

    def tearDown(self):
        core.has_calendar_permission = self._orig_perm

    # helpers
    def write_lessons(self, lessons):
        with open(os.path.join(core.data_dir(), 'lessons.json'), 'w', encoding='utf-8') as f:
            json.dump({'lessons': lessons, 'settings': self.settings}, f, ensure_ascii=False)

    def add_event(self, seconds, title='Математика', event_id=7, url=TEAMS,
                  calendar=10, status=0, self_status=1):
        begin = ms_in(seconds)
        fa.W.calendar_rows.append((event_id, title, begin, begin + 45 * 60000,
                                   f"Ссылка: {url}", '', 0, status, self_status, calendar))
        return begin

    def run_cycle(self, times=1):
        for _ in range(times):
            svc._check_and_trigger()
            svc._supervise()

    def state(self):
        return core.load_state()

    def write_action(self, action, sid, ts=None):
        path = os.path.join(core.data_dir(), 'action.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'action': action, 'id': sid,
                       'ts': ts if ts is not None else int(datetime.now().timestamp() * 1000)}, f)

    def write_a11y(self, stage, sid):
        with open(os.path.join(core.data_dir(), 'a11y_status.json'), 'w', encoding='utf-8') as f:
            json.dump({'id': sid, 'stage': stage, 'mic': 0, 'cam': 0,
                       'ts': int(datetime.now().timestamp() * 1000)}, f)

    def session_id(self):
        return 'cal_7_' + str(self.state()['events'][0]['begin'])


class NetworkTests(FlowBase):

    def test_failed_check_is_unknown_not_wifi(self):
        class Boom:
            def getSystemService(self, name):
                raise RuntimeError("нет сервиса")
        orig = core.get_context
        core.get_context = lambda: Boom()
        try:
            self.assertEqual(core.network_status(), 'unknown')
        finally:
            core.get_context = orig

    def test_network_states_are_reported(self):
        for net, expected in [('wifi', 'wifi'), ('cellular', 'cellular'),
                              ('no_internet', 'no_internet'), ('no_network', 'no_network')]:
            fa.W.net = net
            self.assertEqual(core.network_status(), expected, net)

    def test_mobile_data_join_works_without_warning(self):
        fa.W.net = 'cellular'
        self.add_event(30)                                 # скоро — входим сразу
        self.run_cycle()
        self.assertEqual(len(fa.W.launched), 1, "на мобильной сети урок должен открыться")
        self.assertEqual(fa.W.notifications, [], "без настройки предупреждения о сети быть не должно")

    def test_mobile_warning_when_enabled(self):
        self.settings['warn_no_wifi'] = True
        self.write_lessons({})
        fa.W.net = 'cellular'
        self.add_event(200)
        self.run_cycle()
        notice = [n for n in fa.W.notifications if n['actions']][0]
        self.assertIn('мобильная сеть', notice['text'])
        self.assertEqual(fa.W.launched, [], "за 5 минут до урока входа ещё нет")

    def test_no_internet_warning_in_pre_notice(self):
        fa.W.net = 'no_internet'
        self.add_event(200)
        self.run_cycle()
        notice = [n for n in fa.W.notifications if n['actions']][0]
        self.assertIn('Нет интернета', notice['text'])

    def test_no_network_warning_in_pre_notice(self):
        fa.W.net = 'no_network'
        self.add_event(200)
        self.run_cycle()
        notice = [n for n in fa.W.notifications if n['actions']][0]
        self.assertIn('Нет Wi-Fi и мобильной сети', notice['text'])

    def test_join_attempted_even_without_internet(self):
        # Зафиксированное поведение: приложение пытается войти и без сети.
        fa.W.net = 'no_internet'
        self.add_event(30)
        self.run_cycle()
        self.assertEqual(len(fa.W.launched), 1)


class JoinTests(FlowBase):

    def test_pre_notice_sent_once_with_buttons(self):
        self.add_event(200)
        self.run_cycle(times=3)
        notices = [n for n in fa.W.notifications if n['actions']]
        self.assertEqual(len(notices), 1)
        self.assertEqual(fa.W.launched, [])

    def test_auto_join_once(self):
        self.add_event(30)
        self.run_cycle(times=3)
        self.assertEqual(len(fa.W.launched), 1)
        self.assertEqual(fa.W.launched[0]['url'], TEAMS)

    def test_no_pre_notice_after_join(self):
        self.add_event(30)
        self.run_cycle()
        self.assertFalse([n for n in fa.W.notifications if n['actions']])

    def test_skip_before_join_prevents_entry(self):
        self.add_event(200)
        self.run_cycle()
        svc._handle_action(self.settings, core.load_lessons())   # без действия — ничего
        self.write_action('skip', self.session_id())
        svc._handle_action(self.settings, core.load_lessons())
        self.run_cycle(times=2)
        self.assertEqual(fa.W.launched, [])
        self.assertTrue(any(n['title'] == '⏭ Пропущено' for n in fa.W.notifications))

    def test_join_now_enters_before_auto_time(self):
        self.add_event(200)                       # до автозахода ещё 3 минуты
        self.run_cycle()
        self.write_action('join', self.session_id())
        svc._handle_action(self.settings, core.load_lessons())
        self.assertEqual(len(fa.W.launched), 1)

    def test_join_now_after_join_reports_no_double_entry(self):
        self.add_event(30)
        self.run_cycle()
        self.write_action('join', self.session_id())
        svc._handle_action(self.settings, core.load_lessons())
        self.assertEqual(len(fa.W.launched), 1, "второй вход не должен происходить")
        self.assertTrue(any('уже выполнен' in n['text'] for n in fa.W.notifications))

    def test_skip_after_join_says_nothing_to_skip(self):
        self.add_event(30)
        self.run_cycle()
        self.write_action('skip', self.session_id())
        svc._handle_action(self.settings, core.load_lessons())
        self.assertTrue(any('пропуск не нужен' in n['text'] for n in fa.W.notifications))

    def test_stale_action_is_ignored(self):
        self.add_event(200)
        self.run_cycle()
        old = int(datetime.now().timestamp() * 1000) - 10 * 60000
        self.write_action('join', self.session_id(), ts=old)
        svc._handle_action(self.settings, core.load_lessons())
        self.assertEqual(fa.W.launched, [])


class QuietAndLockTests(FlowBase):

    def test_dnd_saved_and_restored_to_users_own_mode(self):
        fa.W.dnd_filter = 2                       # пользователь сам включил «Только приоритетные»
        self.add_event(30)
        self.run_cycle()
        self.assertEqual(fa.W.dnd_filter, 4, "на время урока — режим будильников")
        self.write_a11y('left', self.session_id())
        self.run_cycle()
        self.assertEqual(fa.W.dnd_filter, 2, "после урока — прежний режим пользователя")
        self.assertNotIn('saved_dnd', self.state())

    def test_lock_after_exit(self):
        self.add_event(30)
        self.run_cycle()
        self.write_a11y('left', self.session_id())
        self.run_cycle()
        self.assertTrue(os.path.exists(os.path.join(core.data_dir(), 'lock_request.json')))

    def test_no_lock_when_disabled(self):
        self.settings['lock_after_lesson'] = False
        self.write_lessons({})
        self.add_event(30)
        self.run_cycle()
        self.write_a11y('left', self.session_id())
        self.run_cycle()
        self.assertFalse(os.path.exists(os.path.join(core.data_dir(), 'lock_request.json')))

    def test_no_dnd_change_without_policy_access(self):
        fa.W.dnd_granted = False
        self.add_event(30)
        self.run_cycle()
        self.assertEqual(fa.W.dnd_filter, 1)
        self.assertEqual(fa.W.dnd_calls, [])

    def test_no_dnd_change_when_disabled(self):
        self.settings['dnd_during_lesson'] = False
        self.write_lessons({})
        self.add_event(30)
        self.run_cycle()
        self.assertEqual(fa.W.dnd_calls, [])


class WidgetAndCalendarTests(FlowBase):

    def test_widget_written_and_pushed_only_on_change(self):
        self.add_event(200)
        self.run_cycle(times=3)
        self.assertEqual(fa.W.broadcasts, 1)
        with open(os.path.join(core.data_dir(), 'widget.json'), encoding='utf-8') as f:
            w = json.load(f)
        self.assertEqual(w['title'], 'Математика')
        self.assertIn('Автоматизация включена', w['status'])

    def test_widget_status_shows_network_problem(self):
        fa.W.net = 'no_internet'
        self.add_event(200)
        self.run_cycle()
        with open(os.path.join(core.data_dir(), 'widget.json'), encoding='utf-8') as f:
            self.assertIn('Нет интернета', json.load(f)['status'])

    def test_calendar_filters(self):
        now = datetime.now()
        begin = int((now + timedelta(hours=1)).timestamp() * 1000)
        end = begin + 3600000
        fa.W.calendars = [(20, 'ru.russian#holiday@group.v.calendar.google.com', 'Праздники'),
                          (10, 'me@gmail.com', 'Мой'),
                          (30, 'work', 'Работа')]
        fa.W.calendar_rows = [
            (1, 'Математика', begin, end, f"Ссылка: {TEAMS}", '', 0, 0, 1, 10),       # ок
            (2, 'Физика', begin, end, '', TEAMS, 0, 0, 1, 10),                     # ок: ссылка в месте
            (3, 'Английский', begin, end, TEAMS, '', 0, 0, 2, 10),                 # отклонён
            (4, 'Химия', begin, end, TEAMS, '', 0, 2, 1, 10),                      # отменён
            (5, 'Выходной', begin, end, TEAMS, '', 0, 0, 1, 20),                   # праздничный календарь
            (6, 'Каникулы', begin, end, TEAMS, '', 0, 0, 1, 10),                   # слово в названии
            (7, 'Весь день', begin, end, TEAMS, '', 1, 0, 1, 10),                  # весь день
            (8, 'Без ссылки', begin, end, 'нет', '', 0, 0, 1, 10),                 # нет Teams-ссылки
            (9, 'Математика', begin, end, TEAMS, '', 0, 0, 1, 30),                 # дубль из другого календаря
        ]
        names = [e['name'] for e in core.fetch_calendar_events()]
        self.assertEqual(names, ['Математика', 'Физика'])

    def test_duplicate_lesson_not_started_when_calendar_has_it(self):
        self.add_event(30, title='Математика')
        now = datetime.now()
        self.write_lessons({'L': {'id': 'L', 'name': 'математика', 'time':
                                  (now + timedelta(seconds=30)).strftime('%H:%M'),
                                  'days': list(range(7)), 'meeting_url': TEAMS,
                                  'enabled': True}})
        self.run_cycle()
        self.assertEqual(len(fa.W.launched), 1, "один урок, а не два входа")


class NetworkStatusRules(unittest.TestCase):

    def test_pure_rules(self):
        self.assertEqual(core.net_problem({}, 'unknown'), '')
        self.assertEqual(core.net_problem({}, 'wifi'), '')
        self.assertEqual(core.net_problem({}, 'cellular'), '')
        self.assertIn('мобильная', core.net_problem({'warn_no_wifi': True}, 'cellular'))


if __name__ == '__main__':
    unittest.main()
