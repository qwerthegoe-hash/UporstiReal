[app]

# ── Основное ───────────────────────────────────────────────────────────────────
title          = Teams Auto-Joiner
package.name   = teamsautojoiner
package.domain = org.student.teams
source.dir     = .
source.include_exts = py,png,jpg,kv,atlas,json,java,xml
source.exclude_dirs = tests,__pycache__
version        = 1.4.0

# ── Зависимости ────────────────────────────────────────────────────────────────
# python3, kivy, kivymd — основные
# android, pyjnius — доступ к Android API
requirements = python3,kivy==2.2.1,kivymd==1.1.1,android,pyjnius

# ── Android ────────────────────────────────────────────────────────────────────
orientation         = portrait
fullscreen          = 0
android.api         = 33
android.minapi      = 26
android.ndk         = 25b
android.sdk         = 33
android.accept_sdk_license = True

# WakeLock для пробуждения экрана
android.wakelock    = True

# ── Разрешения ─────────────────────────────────────────────────────────────────
android.permissions = \
    INTERNET,\
    RECEIVE_BOOT_COMPLETED,\
    WAKE_LOCK,\
    FOREGROUND_SERVICE,\
    FOREGROUND_SERVICE_DATA_SYNC,\
    SYSTEM_ALERT_WINDOW,\
    REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,\
    USE_FULL_SCREEN_INTENT,\
    POST_NOTIFICATIONS,\
    VIBRATE,\
    READ_CALENDAR,\
    ACCESS_NETWORK_STATE,\
    ACCESS_NOTIFICATION_POLICY

# ── Фоновый сервис ─────────────────────────────────────────────────────────────
# Формат: НазваниеСервиса:путь/к/service/main.py:тип
# foreground = сервис не убивается Android при сворачивании
services = TeamsService:service/main.py:foreground:sticky

# ── v1.1.0: автозапуск + Accessibility (нативный Java-код) ────────────────────
# Java-классы BootReceiver и TeamsAccessibilityService
android.add_src = java
# XML-ресурсы (конфиг AccessibilityService, строка описания)
android.add_resources = res
# <receiver> и <service> внутри <application> (см. manifest/application_xml.xml)
android.extra_manifest_application_xml = manifest/application_xml.xml

# ── v1.4.0: приём ссылки из меню «Поделиться» (Teams) ─────────────────────────
# Фильтр намерений для главной активности (SEND, text/plain)
android.manifest.intent_filters = manifest/intent_filters.xml

# ── Иконка (опционально) ───────────────────────────────────────────────────────
# presplash.filename = %(source.dir)s/data/presplash.png
# icon.filename      = %(source.dir)s/data/icon.png

# ── Метаданные ─────────────────────────────────────────────────────────────────
android.release_artifact = apk

[buildozer]
log_level    = 2
warn_on_root = 1
